#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

ARM_JOINT_NAMES = [
    "arm_1_joint",
    "arm_2_joint",
    "arm_3_joint",
    "arm_4_joint",
    "arm_5_joint",
    "arm_6_joint",
    "arm_7_joint",
]


class HandsUpJoint(object):
    def __init__(self):
        rospy.init_node("hands_up_joint")
        rospy.loginfo("[HANDS_UP_JOINT] Node started")

        # 和 grasp_try 一样的话题
        self.arm_pub = rospy.Publisher(
            "/arm_controller/command",
            JointTrajectory,
            queue_size=1
        )

        rospy.loginfo("[HANDS_UP_JOINT] Waiting for /joint_states ...")
        joint_state = rospy.wait_for_message("/joint_states", JointState)
        rospy.loginfo("[HANDS_UP_JOINT] joint_states received")

        # 当前关节角
        name_to_pos = dict(zip(joint_state.name, joint_state.position))

        current_arm_pos = []
        for jn in ARM_JOINT_NAMES:
            if jn not in name_to_pos:
                rospy.logerr("[HANDS_UP_JOINT] Joint %s not found in joint_states!", jn)
                return
            current_arm_pos.append(name_to_pos[jn])

        rospy.loginfo("[HANDS_UP_JOINT] Current arm positions: %s",
                      ", ".join(["%.3f" % p for p in current_arm_pos]))

        # === 在当前姿态基础上来一个“很明显”的抬手动作 ===
        target_arm_pos = list(current_arm_pos)

        # 这里动作故意调大一点，便于你在 Gazebo 里观察
        # 注意不要超出关节极限（但 Tiago 这些值一般还在安全范围）
        delta_arm2 = 0.5   # 肩往上抬很多
        delta_arm3 = 0.1    # 手臂再弯很多

        target_arm_pos[1] += delta_arm2
        target_arm_pos[2] += delta_arm3

        rospy.loginfo("[HANDS_UP_JOINT] Target arm positions: %s",
                      ", ".join(["%.3f" % p for p in target_arm_pos]))

        # 构造 JointTrajectory
        traj = JointTrajectory()
        traj.joint_names = ARM_JOINT_NAMES

        pt = JointTrajectoryPoint()
        pt.positions = target_arm_pos
        # 和 grasp_try 类似，给一个 3 秒的运动时间
        pt.time_from_start = rospy.Duration(3.0)
        traj.points.append(pt)

        rospy.loginfo("[HANDS_UP_JOINT] Publishing trajectory to /arm_controller/command ...")

        # 👉 多发几次，增加被 controller 接收的概率
        for i in range(5):
            self.arm_pub.publish(traj)
            rospy.loginfo("[HANDS_UP_JOINT] Published command #%d", i + 1)
            rospy.sleep(0.1)

        rospy.loginfo("[HANDS_UP_JOINT] Command sent. Done.")


if __name__ == "__main__":
    try:
        HandsUpJoint()
    except rospy.ROSInterruptException:
        pass

