#ifndef GRASP_H
#define GRASP_H

// ROS
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <trajectory_msgs/JointTrajectoryPoint.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_datatypes.h>

// PCL
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/filters/extract_indices.h>
#include <pcl/filters/passthrough.h>
#include <pcl/common/centroid.h>
#include <pcl/search/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl_ros/transforms.h>

// Eigen
#include <Eigen/Dense>
#include <Eigen/Core>
#include <Eigen/Geometry>

// MoveIt
#include <moveit/move_group_interface/move_group_interface.h>

// 避障 / 场景
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/CollisionObject.h>
#include <shape_msgs/SolidPrimitive.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/common/common.h>

// PCL point type with label
typedef pcl::PointXYZL PointT1;
typedef pcl::PointCloud<PointT1> PointCloudL;

// 抓取 + 放置 类
class Grasper
{
public:
    // 桌面点云只订阅一次的 subscriber（在外部 main 里创建）
    ros::Subscriber table_cloud_sub_once_;

    // 构造函数：初始化 MoveIt / 参数 / 夹爪等
    Grasper(ros::NodeHandle& nh);

    // 订阅到带 label 的点云后的回调（用于抓取目标物体）
    void pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg);

    // 订阅到桌面点云后的回调（拟合桌面平面 + 添加桌子碰撞体 + 记录桌子信息）
    void tableCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg);

private:
    // ================== 状态成员 ==================
    bool has_target_pose_ = false;   // 目前没用到，可以保留
    geometry_msgs::PoseStamped cached_grasp_pose_;
    geometry_msgs::PoseStamped cached_pregrasp_pose_;

    // 缓存点云：只处理第一帧，防止 callback 多次进入
    sensor_msgs::PointCloud2ConstPtr cached_cloud_;
    bool got_cloud_ = false;

    // 桌子碰撞体是否已经初始化
    bool table_obstacle_initialized_ = false;

    // ================== MoveIt & 夹爪 ==================
    ros::Publisher gripper_pub_;  // 发布 JointTrajectory 控制夹爪
    moveit::planning_interface::MoveGroupInterface move_group_;  // arm 组
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface_; // 场景接口
    ros::Subscriber table_cloud_sub_; // 你之前的订阅器（可选）

    // ================== 抓取参数（从参数服务器读取） ==================
    int    target_label_;      // 要抓取的 label
    double x_offset_;          // 抓取点 x 偏移
    double y_offset_;          // 抓取点 y 偏移
    double z_offset_;          // 抓取点 z 偏移（通常在物体上方）
    double grasp_rpy_[3];      // 抓取姿态 roll/pitch/yaw
    double pregrasp_offset_x;  // pre-grasp 相对 grasp 的偏移
    double pregrasp_offset_y;
    double pregrasp_offset_z;

    // ================== 放置参数（从 place_bottle.py 移植） ==================
    // 对应 Python 中的 pre_height / place_offset / retreat_height
    double place_pre_height_;      // 预放置高度（末端相对桌面的高度）
    double place_offset_;          // 放瓶子时离桌面的高度（略高一点）
    double place_retreat_height_;  // 放完后抬起到桌面上方的高度

    // ================== 桌子几何信息 ==================
    // 由 tableCloudCallback 拟合后保存，用于 placeBottle 计算位置
    double table_center_x_;
    double table_center_y_;
    double table_center_z_;
    double table_size_x_;
    double table_size_y_;
    double table_size_z_;

    // ================== 功能函数 ==================

    // 机械臂运动到某个末端位姿（MoveIt 规划 + 执行）
    bool moveArmToTarget(const geometry_msgs::PoseStamped& target);

    // 笛卡尔空间沿给定方向直线运动 distance 米
    bool moveEndEffectorStraightDirection(double dx, double dy, double dz, double distance);

    // 关闭夹爪（夹紧物体）
    void closeGripper();

    // 打开夹爪（对应 Python 的 open_gripper）
    void openGripper();

    // 主抓取流程（基于带 label 点云）
    bool grasp(const sensor_msgs::PointCloud2ConstPtr& msg, int traget_label);

    // 放瓶子流程（等价于 place_bottle.py 的 place_bottle）
    bool placeBottle();
};

#endif // GRASP_H

