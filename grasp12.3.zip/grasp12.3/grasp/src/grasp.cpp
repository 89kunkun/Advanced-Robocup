#include <grasp/grasp.h>

// ================== 构造函数 ==================
// 初始化 MoveIt 的 MoveGroup、夹爪发布器、以及从参数服务器读取各种参数
Grasper::Grasper(ros::NodeHandle& nh)
    : move_group_("arm")
{
    // 夹爪控制器的 topic，要和控制器配置一致
    gripper_pub_ = nh.advertise<trajectory_msgs::JointTrajectory>(
        "/gripper_controller/command", 1);

    // MoveGroup 基本配置
    move_group_.setPoseReferenceFrame("base_link");    // 规划参考坐标系
    move_group_.setEndEffectorLink("gripper_link");    // 末端执行器 link 名
    move_group_.setGoalTolerance(0.03);                // 位置/姿态容差
    move_group_.setMaxVelocityScalingFactor(0.3);      // 速度缩放
    move_group_.setPlanningTime(15.0);                 // 规划时间
    move_group_.setStartStateToCurrentState();
    move_group_.setPlannerId("RRTConnectkConfigDefault");

    // ====== 抓取相关参数 ======
    nh.param("target_label", target_label_, 1);

    nh.param("x_offset", x_offset_, 0.0);
    nh.param("y_offset", y_offset_, 0.0);
    nh.param("z_offset", z_offset_, 0.1); // 默认在物体上方 10cm

    nh.param("grasp_roll",  grasp_rpy_[0], -M_PI/2);
    nh.param("grasp_pitch", grasp_rpy_[1], 0.0);
    nh.param("grasp_yaw",   grasp_rpy_[2], -M_PI/2);

    nh.param("pregrasp_offset_x", pregrasp_offset_x, 0.0);
    nh.param("pregrasp_offset_y", pregrasp_offset_y, 0.0);
    nh.param("pregrasp_offset_z", pregrasp_offset_z, 0.0);

    // ====== 放置相关参数（来自 place_bottle.py） ======
    // 对应 Python 中的 pre_height / place_offset / retreat_height
    nh.param("place_pre_height",      place_pre_height_,      0.15); // 桌面上 15cm
    nh.param("place_offset",          place_offset_,          0.10); // 放置时离桌面 10cm
    nh.param("place_retreat_height",  place_retreat_height_,  0.20); // 放完抬到桌面上 20cm

    ROS_INFO("[INIT] target_label = %d", target_label_);
    ROS_INFO("[INIT] grasp offset = (%.3f, %.3f, %.3f)",
             x_offset_, y_offset_, z_offset_);
    ROS_INFO("[INIT] grasp RPY = (%.3f, %.3f, %.3f)",
             grasp_rpy_[0], grasp_rpy_[1], grasp_rpy_[2]);
    ROS_INFO("[INIT] pregrasp offset = (%.3f, %.3f, %.3f)",
             pregrasp_offset_x, pregrasp_offset_y, pregrasp_offset_z);
    ROS_INFO("[INIT] place heights: pre=%.3f, offset=%.3f, retreat=%.3f",
             place_pre_height_, place_offset_, place_retreat_height_);
}

// ================== 目标点云回调 ==================
// 订阅到带 label 的点云后，只处理第一帧，然后调用 grasp()
void Grasper::pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg)
{
    if (!got_cloud_)
    {
        ROS_INFO("[POINTCLOUD] 收到第一帧带标签点云，开始执行 grasp()。");
        cached_cloud_ = msg;
        got_cloud_ = true;
        grasp(cached_cloud_, target_label_);
    }
    else
    {
        ROS_DEBUG("[POINTCLOUD] 已经处理过点云，本帧忽略。");
    }
}

// ================== 桌面点云回调 ==================
// 用来拟合桌面平面、添加桌子碰撞体，并保存桌子几何信息
void Grasper::tableCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg)
{
    ROS_INFO("[TABLE] 收到桌面点云，开始平面拟合。");

    // 1. Point cloud conversion: ROS -> PCL
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromROSMsg(*msg, *cloud);
    if (cloud->empty())
    {
        ROS_WARN("[TABLE] 桌面点云为空，返回。");
        return;
    }

    // 2. 使用 RANSAC 拟合平面
    pcl::SACSegmentation<pcl::PointXYZ> seg;
    seg.setOptimizeCoefficients(true);
    seg.setModelType(pcl::SACMODEL_PLANE);
    seg.setMethodType(pcl::SAC_RANSAC);
    seg.setDistanceThreshold(0.015);
    seg.setInputCloud(cloud);

    pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
    pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
    seg.segment(*inliers, *coefficients);
    if (inliers->indices.empty())
    {
        ROS_WARN("[TABLE] 未找到平面内点，桌子拟合失败。");
        return;
    }

    pcl::ExtractIndices<pcl::PointXYZ> extract;
    extract.setInputCloud(cloud);
    extract.setIndices(inliers);
    pcl::PointCloud<pcl::PointXYZ>::Ptr table_inlier_cloud(new pcl::PointCloud<pcl::PointXYZ>);
    extract.filter(*table_inlier_cloud);

    // 3. 计算桌面的包围盒 (min / max)
    pcl::PointXYZ min_pt, max_pt;
    pcl::getMinMax3D(*table_inlier_cloud, min_pt, max_pt);

    double box_x = max_pt.x - min_pt.x;
    double box_y = max_pt.y - min_pt.y;
    double box_z = 0.4; // 给一个固定厚度
    double center_x = (min_pt.x + max_pt.x) / 2.0;
    double center_y = (min_pt.y + max_pt.y) / 2.0;
    double center_z = max_pt.z - box_z + 0.08;

    // 保存桌子的几何信息，供 placeBottle 使用
    table_center_x_ = center_x;
    table_center_y_ = center_y;
    table_center_z_ = center_z;
    table_size_x_   = box_x;
    table_size_y_   = box_y;
    table_size_z_   = box_z;

    // 4. 构造桌子碰撞体
    moveit_msgs::CollisionObject table_obj;
    table_obj.header.frame_id = "base_link";
    table_obj.id = "table";

    shape_msgs::SolidPrimitive primitive;
    primitive.type = primitive.BOX;
    primitive.dimensions = {box_x, box_y, box_z};

    geometry_msgs::Pose table_pose;
    table_pose.position.x = center_x;
    table_pose.position.y = center_y;
    table_pose.position.z = center_z;
    table_pose.orientation.w = 1.0;

    table_obj.primitives.push_back(primitive);
    table_obj.primitive_poses.push_back(table_pose);
    table_obj.operation = table_obj.ADD;

    // 5. 发布到规划场景
    planning_scene_interface_.applyCollisionObject(table_obj);

    table_obstacle_initialized_ = true;
    // 如果只订阅一次桌面点云，这里可以 shutdown 掉
    if (table_cloud_sub_once_)
        table_cloud_sub_once_.shutdown();

    ROS_INFO("[TABLE] 添加桌子碰撞体: center(%.3f, %.3f, %.3f) size(%.3f, %.3f, %.3f)",
             center_x, center_y, center_z, box_x, box_y, box_z);
}

// ================== 主抓取函数 ==================
// 从带 label 点云里取出指定 label 的点 -> 计算质心 -> pregrasp -> 直线插入 grasp -> 夹紧 -> 抬起 -> 放置
bool Grasper::grasp(const sensor_msgs::PointCloud2ConstPtr& msg, int target_label)
{
    ROS_INFO("[GRASP] 开始抓取流程，目标 label = %d", target_label);

    // Step 1: Convert PointCloud2 to PCL PointCloud<PointXYZL>
    pcl::PointCloud<PointT1>::Ptr cloud(new pcl::PointCloud<PointT1>);
    pcl::fromROSMsg(*msg, *cloud);

    if (cloud->empty())
    {
        ROS_ERROR("[GRASP] 输入点云为空，无法抓取。");
        return false;
    }

    // Step 2: Extract all points with the target label
    std::vector<PointT1> target_points;
    for (const auto& pt : cloud->points)
    {
        if (pt.label == target_label)
            target_points.push_back(pt);
    }

    if (target_points.empty())
    {
        ROS_WARN("[GRASP] 没有找到 label = %d 的点。", target_label);
        return false;
    }

    // Step 3: Compute centroid of the target cluster
    Eigen::Vector3d centroid(0, 0, 0);
    for (const auto& pt : target_points)
        centroid += Eigen::Vector3d(pt.x, pt.y, pt.z);
    centroid /= static_cast<double>(target_points.size());

    ROS_INFO("[GRASP] 目标质心: (%.3f, %.3f, %.3f)",
             centroid.x(), centroid.y(), centroid.z());

    // Step 4: Construct grasp pose
    // Orientation: RPY -> Quaternion
    tf::Quaternion q;
    q.setRPY(grasp_rpy_[0], grasp_rpy_[1], grasp_rpy_[2]);
    geometry_msgs::Quaternion quat;
    tf::quaternionTFToMsg(q, quat);

    // --- Grasp Pose ---
    geometry_msgs::PoseStamped grasp_pose;
    grasp_pose.header.frame_id = msg->header.frame_id; // 一般是相机坐标系或 base_link，看你数据
    grasp_pose.header.stamp    = ros::Time::now();
    grasp_pose.pose.position.x = centroid.x() + x_offset_;
    grasp_pose.pose.position.y = centroid.y() + y_offset_;
    grasp_pose.pose.position.z = centroid.z() + z_offset_;
    grasp_pose.pose.orientation = quat;

    // --- Pregrasp Pose ---
    geometry_msgs::PoseStamped pregrasp_pose = grasp_pose;
    pregrasp_pose.pose.position.x += pregrasp_offset_x;
    pregrasp_pose.pose.position.y += pregrasp_offset_y;
    pregrasp_pose.pose.position.z += pregrasp_offset_z;

    ROS_INFO("[GRASP] pregrasp 位姿: frame=%s pos(%.3f, %.3f, %.3f)",
             pregrasp_pose.header.frame_id.c_str(),
             pregrasp_pose.pose.position.x,
             pregrasp_pose.pose.position.y,
             pregrasp_pose.pose.position.z);

    // Step 5: Move the arm

    // 5.1 移动到 pregrasp
    ROS_INFO("[GRASP] 移动到 pregrasp 位姿...");
    if (!moveArmToTarget(pregrasp_pose))
    {
        ROS_ERROR("[GRASP] 无法到达 pregrasp 位姿，终止。");
        ros::shutdown();
        return false;
    }
    ROS_INFO("[GRASP] 已到达 pregrasp。");
    ros::Duration(1.0).sleep();

    // 5.2 直线插入到 grasp 位姿（方向和距离你之前就是 (1,0,-1,0.16)）
    ROS_INFO("[GRASP] 笛卡尔直线插入到 grasp 位姿...");
    if (!moveEndEffectorStraightDirection(1, 0, -1, 0.16))
    {
        ROS_ERROR("[GRASP] 无法插入到 grasp 位姿，终止。");
        ros::shutdown();
        return false;
    }
    ROS_INFO("[GRASP] 已到达 grasp 位姿。");
    ros::Duration(1.0).sleep();

    // 5.3 关闭夹爪抓紧
    ROS_INFO("[GRASP] 关闭夹爪抓取瓶子...");
    closeGripper();
    ros::Duration(1.0).sleep();

    // 5.4 直线向上抬一点，避免碰撞桌面
    ROS_INFO("[GRASP] 直线向上抬起...");
    if (!moveEndEffectorStraightDirection(0, 0, 1, 0.01))
    {
        ROS_ERROR("[GRASP] 抬起失败，终止。");
        ros::shutdown();
        return false;
    }
    ROS_INFO("[GRASP] 抬起完成。");
    ros::Duration(1.0).sleep();

    // ====== 新增：调用 placeBottle() 将瓶子放回桌子上 ======
    ROS_INFO("[GRASP] 开始执行放置动作 placeBottle()...");
    if (!placeBottle())
    {
        ROS_ERROR("[GRASP] placeBottle() 失败，终止。");
        ros::shutdown();
        return false;
    }

    ROS_INFO("[GRASP] 抓取 + 放置 流程全部完成，关闭节点。");
    ros::shutdown();
    return true;
}

// ================== MoveGroup: 移动到目标位姿 ==================
bool Grasper::moveArmToTarget(const geometry_msgs::PoseStamped& target)
{
    ROS_INFO("[ARM] moveArmToTarget(): frame=%s pos(%.3f, %.3f, %.3f)",
             target.header.frame_id.c_str(),
             target.pose.position.x,
             target.pose.position.y,
             target.pose.position.z);

    move_group_.setPoseTarget(target);
    move_group_.setMaxVelocityScalingFactor(0.2);   // 稍微慢一点，安全一些
    move_group_.setMaxAccelerationScalingFactor(0.1);

    ROS_INFO("[ARM] moveArmToTarget(): 开始执行 move()");
    moveit::planning_interface::MoveItErrorCode result = move_group_.move();
    ROS_INFO("[ARM] moveArmToTarget(): move() 结束，result = %d", result.val);

    if (result != moveit::planning_interface::MoveItErrorCode::SUCCESS)
    {
        ROS_ERROR("[ARM] 机械臂运动执行失败。");
        return false;
    }

    return true;
}

// ================== 笛卡尔直线运动 ==================
bool Grasper::moveEndEffectorStraightDirection(double dx, double dy, double dz, double distance)
{
    // 归一化方向向量
    Eigen::Vector3d dir(dx, dy, dz);
    if (dir.norm() < 1e-6)
    {
        ROS_ERROR("[CARTESIAN] 方向向量为零！");
        return false;
    }
    dir.normalize();

    // 当前末端位姿
    geometry_msgs::PoseStamped current_pose =
        move_group_.getCurrentPose(move_group_.getEndEffectorLink());
    geometry_msgs::Pose start = current_pose.pose;
    geometry_msgs::Pose target = start;

    // 计算目标点
    target.position.x += dir.x() * distance;
    target.position.y += dir.y() * distance;
    target.position.z += dir.z() * distance;

    std::vector<geometry_msgs::Pose> waypoints;
    waypoints.push_back(start);
    waypoints.push_back(target);

    moveit_msgs::RobotTrajectory trajectory;
    double fraction = move_group_.computeCartesianPath(
        waypoints, 0.005, 0.0, trajectory);

    ROS_INFO("[CARTESIAN] 路径 fraction = %.2f", fraction);
    if (fraction < 0.99)
    {
        ROS_ERROR("[CARTESIAN] 笛卡尔路径规划失败。");
        return false;
    }

    moveit::planning_interface::MoveGroupInterface::Plan plan;
    plan.trajectory_ = trajectory;
    if (move_group_.execute(plan) != moveit::planning_interface::MoveItErrorCode::SUCCESS)
    {
        ROS_ERROR("[CARTESIAN] 笛卡尔轨迹执行失败。");
        return false;
    }

    ROS_INFO("[CARTESIAN] 笛卡尔直线运动完成。");
    return true;
}

// ================== 打开夹爪（来自 Python open_gripper） ==================
void Grasper::openGripper()
{
    trajectory_msgs::JointTrajectory traj;
    traj.joint_names = {"gripper_left_finger_joint", "gripper_right_finger_joint"};

    trajectory_msgs::JointTrajectoryPoint pt;
    pt.positions = {0.04, 0.04};       // 张开一点，数值可根据实际 gripper 调整
    pt.time_from_start = ros::Duration(1.0);
    traj.points.push_back(pt);
    traj.header.stamp = ros::Time::now() + ros::Duration(0.2);

    ROS_INFO("[GRIPPER] 打开夹爪...");
    for (int i = 0; i < 3; ++i)
    {
        gripper_pub_.publish(traj);
        ROS_INFO("[GRIPPER] 发布打开命令 #%d", i + 1);
        ros::Duration(0.1).sleep();
    }
}

// ================== 关闭夹爪（抓紧物体） ==================
void Grasper::closeGripper()
{
    trajectory_msgs::JointTrajectory traj;
    traj.joint_names = {"gripper_left_finger_joint", "gripper_right_finger_joint"};

    trajectory_msgs::JointTrajectoryPoint pt;
    pt.positions = {0.0, 0.0}; // 完全闭合，按实际 gripper 调整
    pt.time_from_start = ros::Duration(3.0);
    traj.points.push_back(pt);
    traj.header.stamp = ros::Time::now() + ros::Duration(0.2);

    ROS_INFO("[GRIPPER] 关闭夹爪...");
    for (int i = 0; i < 3; ++i)
    {
        gripper_pub_.publish(traj);
        ROS_INFO("[GRIPPER] 发布关闭命令 #%d", i + 1);
        ros::Duration(0.1).sleep();
    }
}

// ================== 放瓶子（等价于 place_bottle.py） ==================
// 使用桌子中心和高度参数，规划 pre-place -> place -> retreat
bool Grasper::placeBottle()
{
    ROS_INFO("[PLACE] placeBottle() 被调用。");

    if (!table_obstacle_initialized_)
    {
        ROS_WARN("[PLACE] 桌子碰撞体尚未初始化，无法放置。请检查是否订阅了桌面点云。");
        return false;
    }

    // 桌面顶部高度：碰撞盒中心 + 一半厚度
    const double cx = table_center_x_;
    const double cy = table_center_y_;
    const double cz = table_center_z_ + table_size_z_ * 0.5;  // 桌面 top

    // 当前末端姿态：保持抓取后的姿态
    geometry_msgs::PoseStamped current_pose_stamped =
        move_group_.getCurrentPose(move_group_.getEndEffectorLink());
    const geometry_msgs::Quaternion& ori = current_pose_stamped.pose.orientation;

    // 1) pre-place：在桌面上方 place_pre_height_
    geometry_msgs::PoseStamped pre_pose;
    pre_pose.header.frame_id = "base_link"; // 和 MoveGroup 参考系一致
    pre_pose.header.stamp    = ros::Time::now();
    pre_pose.pose.position.x = cx;
    pre_pose.pose.position.y = cy;
    pre_pose.pose.position.z = cz + place_pre_height_;
    pre_pose.pose.orientation = ori;

    // 2) place：稍微低一点，离桌面 place_offset_
    geometry_msgs::PoseStamped place_pose = pre_pose;
    place_pose.pose.position.z = cz + place_offset_;

    // 3) retreat：放完后抬高到桌面上方 place_retreat_height_
    geometry_msgs::PoseStamped retreat_pose = pre_pose;
    retreat_pose.pose.position.z = cz + place_retreat_height_;

    ROS_INFO("[PLACE] 桌面 top: (%.3f, %.3f, %.3f)", cx, cy, cz);
    ROS_INFO("[PLACE] pre-place:  pos(%.3f, %.3f, %.3f)",
             pre_pose.pose.position.x, pre_pose.pose.position.y, pre_pose.pose.position.z);
    ROS_INFO("[PLACE] place:      pos(%.3f, %.3f, %.3f)",
             place_pose.pose.position.x, place_pose.pose.position.y, place_pose.pose.position.z);
    ROS_INFO("[PLACE] retreat:    pos(%.3f, %.3f, %.3f)",
             retreat_pose.pose.position.x, retreat_pose.pose.position.y, retreat_pose.pose.position.z);

    // 1) 移动到 pre-place
    ROS_INFO("[PLACE] 移动到 pre-place...");
    if (!moveArmToTarget(pre_pose))
    {
        ROS_ERROR("[PLACE] 无法到达 pre-place 位姿。");
        return false;
    }
    ros::Duration(0.5).sleep();

    // 2) 移动到 place
    ROS_INFO("[PLACE] 下移到 place 位姿...");
    if (!moveArmToTarget(place_pose))
    {
        ROS_ERROR("[PLACE] 无法到达 place 位姿。");
        return false;
    }
    ros::Duration(0.5).sleep();

    // 3) 在 place 位置打开夹爪，放下物体
    ROS_INFO("[PLACE] 在 place 位姿打开夹爪，释放瓶子...");
    openGripper();
    ros::Duration(0.5).sleep();

    // 4) 抬起到 retreat 位姿
    ROS_INFO("[PLACE] 抬起到 retreat 位姿...");
    if (!moveArmToTarget(retreat_pose))
    {
        ROS_ERROR("[PLACE] 无法到达 retreat 位姿。");
        return false;
    }
    ros::Duration(0.5).sleep();

    ROS_INFO("[PLACE] PlaceBottle 完成。");
    return true;
}

