import sys
sys.path.append('/home/markus/ROS_Workspace/src/grasp_cola/scripts')
import rospy
import smach
import smach_ros
import subprocess
import actionlib
import math
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseWithCovarianceStamped
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import PointStamped, Twist
from control_msgs.msg import PointHeadAction, PointHeadGoal, FollowJointTrajectoryAction, FollowJointTrajectoryGoal
import time
from detection_msgs.msg import BoundingBox, BoundingBoxes
from std_msgs.msg import String, Bool
#from sound_play.libsoundplay import SoundClient
import message_filters
import cv2
import numpy as np
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge, CvBridgeError
import actionlib
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from test_grasp import create_grasp_sub_sm



class LocalizationState(smach.State):
    def __init__(self, max_duration=60.0, spin_speed=0.7, threshold=0.2):
        smach.State.__init__(self, outcomes=['localized', 'failed'])

        self.spin_speed = spin_speed
        self.threshold = threshold
        self.max_duration = max_duration

        self.covariance_sum = float('inf')
        self.localized = False

        self.pose_sub = rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.pose_callback)
        self.vel_pub = rospy.Publisher("/mobile_base_controller/cmd_vel", Twist, queue_size=1)
        self.localization_client = rospy.ServiceProxy("/global_localization", Empty)

    def pose_callback(self, msg):
        delta = rospy.Time.now() - msg.header.stamp
        if delta.to_sec() > 0.5:
            return

        self.covariance_sum = sum(msg.pose.covariance)
        if self.covariance_sum < self.threshold:
            rospy.loginfo("[Localization] Localization successful. Covariance sum: %.5f", self.covariance_sum)
            self.localized = True

    def execute(self, userdata):
        rospy.loginfo("[Localization] Calling /global_localization...")
        try:
            self.localization_client()
        except rospy.ServiceException as e:
            rospy.logerr("[Localization] Failed to call /global_localization: %s", e)
            return 'failed'

        rospy.loginfo("[Localization] Starting to spin robot for localization...")

        rate = rospy.Rate(10)
        twist = Twist()
        twist.angular.z = self.spin_speed
        start_time = rospy.Time.now()

        while not rospy.is_shutdown():
            self.vel_pub.publish(twist)
            rate.sleep()

            if self.localized:
                rospy.loginfo("[Localization] Localization confirmed. Stopping spin.")
                break

            if (rospy.Time.now() - start_time).to_sec() > self.max_duration:
                rospy.logwarn("[Localization] Localization timed out after %.1f seconds.", self.max_duration)
                self.stop_rotation()
                return 'localized'#failed

        self.stop_rotation()
        return 'localized'

    def stop_rotation(self):
        stop_msg = Twist()
        self.vel_pub.publish(stop_msg)
        rospy.loginfo("[Localization] Robot rotation stopped.")

class NavigateToWaypoint(smach.State): 
    def __init__(self, waypoint_param):
        smach.State.__init__(self, outcomes=['succeeded', 'failed'])
        self.waypoint_param = waypoint_param
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)

    def execute(self, userdata):
        self.client.wait_for_server()

        if not rospy.has_param(self.waypoint_param):
            rospy.logwarn(f"[Navigate] Waypoint param '{self.waypoint_param}' not found.")
            return 'failed'
        
        goal_coords = rospy.get_param(self.waypoint_param)
        if len(goal_coords) != 3:
            rospy.logwarn(f"[Navigate] Invalid coordinates for waypoint '{self.waypoint_param}': {goal_coords}")
            return 'failed'

        x, y, theta = goal_coords
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = x
        goal.target_pose.pose.position.y = y
        goal.target_pose.pose.orientation.z = math.sin(theta / 2.0)
        goal.target_pose.pose.orientation.w = math.cos(theta / 2.0)

        rospy.loginfo(f"[Navigate] Navigating to waypoint '{self.waypoint_param}': x={x:.2f}, y={y:.2f}, theta={theta:.2f} rad")

        self.client.send_goal(goal)  # ✅ 发送目标
        self.client.wait_for_result()  # ✅ 等待结果

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            rospy.loginfo(f"[Navigate] Arrived at '{self.waypoint_param}'.")
            return 'succeeded'
        else:
            rospy.logwarn(f"[Navigate] Failed to reach '{self.waypoint_param}'.")
            return 'failed'

class ReturnArmHome(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['succeeded', 'aborted'])

        # 初始化 action client，确保与控制器名称一致
        self.arm_client = actionlib.SimpleActionClient('/arm_controller/follow_joint_trajectory', FollowJointTrajectoryAction)
        rospy.loginfo("[ReturnArmHome] Waiting for arm_controller action server...")
        if not self.arm_client.wait_for_server(timeout=rospy.Duration(5.0)):
            rospy.logerr("[ReturnArmHome] Arm action server not available!")
            self.arm_client = None

    def execute(self, userdata):
        if self.arm_client is None:
            rospy.logerr("[ReturnArmHome] Action client not initialized.")
            return 'aborted'

        rospy.loginfo("[ReturnArmHome] Returning arm to home pose...")
        home_goal = FollowJointTrajectoryGoal()
        home_traj = JointTrajectory()
        home_traj.joint_names = [
            'arm_1_joint', 'arm_2_joint', 'arm_3_joint',
            'arm_4_joint', 'arm_5_joint', 'arm_6_joint', 'arm_7_joint'
        ]
        home_point = JointTrajectoryPoint()
        home_point.positions = [0.2, -1.34, -0.2, 1.94, -1.57, 1.37, 0.0]  # 你的home位姿
        home_point.time_from_start = rospy.Duration(3.0)

        home_traj.points.append(home_point)
        home_goal.trajectory = home_traj
        home_goal.trajectory.header.stamp = rospy.Time.now() + rospy.Duration(0.5)

        self.arm_client.send_goal(home_goal)
        rospy.loginfo("[ReturnArmHome] Sent goal, waiting for result...")

        if self.arm_client.wait_for_result(rospy.Duration(10.0)):
            rospy.loginfo("[ReturnArmHome] Arm returned to home.")
            return 'succeeded'
        else:
            rospy.logwarn("[ReturnArmHome] Timeout waiting for arm to reach home.")
            return 'aborted'

class DetectPeople(smach.State):
    def __init__(self):
        rospy.loginfo("[DetectPeople] Init start")    
        smach.State.__init__(self, outcomes=['two_detected', 'not_detected'])
        self.detection_sub = rospy.Subscriber('/yolov5/detections', BoundingBoxes, self.detection_callback)
        self.control_pub = rospy.Publisher('/startyolo', Bool, queue_size=1)

        self.person_count = 0
        self.required_count = 5
        self.last_detection_time = 0

        # 头部朝向控制
        rospy.loginfo("[DetectPeople] Creating head client...")        
        self.head_client = actionlib.SimpleActionClient("/head_controller/point_head_action", PointHeadAction)

        rospy.loginfo("[DetectPeople] Waiting for head controller server...")        
        if not self.head_client.wait_for_server(rospy.Duration(5.0)):
            rospy.logerr("[DetectPeople] Timeout waiting for head controller")
            raise RuntimeError("Head controller action server not available")
        rospy.loginfo("[DetectPeople] Head controller server is ready.")
        rospy.loginfo("[DetectPeople] Init finished")

    def detection_callback(self, msg):
        # 每收到一次消息，如果包含至少一个"person"，就+1
        count = sum(1 for box in msg.bounding_boxes if box.Class == "person")
        if count >= 1:
            self.person_count += 1
            self.last_detection_time = time.time()
        else:
            self.person_count = 0  # 重置连续性统计

    def point_head_to_target(self, target_x, target_y, target_z):
        goal = PointHeadGoal()
        goal.target.header.frame_id = "map"
        goal.target.point.x = target_x
        goal.target.point.y = target_y
        goal.target.point.z = target_z
        goal.min_duration = rospy.Duration(1.0)
        goal.pointing_axis.x = 1.0
        goal.pointing_axis.y = 0.0
        goal.pointing_axis.z = 0.0
        goal.pointing_frame = "xtion_rgb_optical_frame"  # 或其他适配 frame
        self.head_client.send_goal(goal)
        self.head_client.wait_for_result()

    def move_head(self, joint1, joint2):
        pub = rospy.Publisher('/head_controller/command', JointTrajectory, queue_size=1)
        rospy.sleep(0.5)  # 确保 publisher 建立连接

        traj = JointTrajectory()
        traj.joint_names = ['head_1_joint', 'head_2_joint']
        point = JointTrajectoryPoint()
        point.positions = [joint1, joint2]
        point.time_from_start = rospy.Duration(1.0)
        traj.points.append(point)

        rospy.loginfo(f"[DetectPeople] Moving head to ({joint1}, {joint2})")
        pub.publish(traj)

    def execute(self, userdata):
        rospy.loginfo("[DetectPeople] Start pointing head and waiting for detections...")
        self.control_pub.publish(Bool(data=True))
        # Step 1: 朝向门口
        self.point_head_to_target(-3.528, -0.943, 1.2)

        # Step 2: 初始化状态
        start_time = time.time()
        timeout = 10  # 最大检测时间

        rate = rospy.Rate(10)
        while time.time() - start_time < timeout:
            if self.person_count >= self.required_count:
                rospy.loginfo("[DetectPeople] Detected persons for sufficient duration.")
                self.control_pub.publish(Bool(data=False))
                self.move_head(-0.3, 0.3)
                return 'two_detected'
            rate.sleep()

        rospy.logwarn("[DetectPeople] Timeout: Not enough person detections.")
        self.control_pub.publish(Bool(data=False))
        return 'not_detected'

class RecognizeFaceAndGreet(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['completed', 'failed'])

        self.name = None
        self.drink = None
        self.name_received = False
        self.drink_received = False
        self.ask_follow_end_received = False 
        
        self.start_pub = rospy.Publisher('/start_recognize_face', Bool, queue_size=1)

    def name_cb(self, msg):
        self.name = msg.data.strip()
        self.name_received = True

    def drink_cb(self, msg):
        self.drink = msg.data.strip()
        self.drink_received = True

    def ask_follow_cb(self, msg):
        if msg.data:
            self.ask_follow_end_received = True

    def execute(self, userdata):
        rospy.loginfo("[RecognizeFace] Starting face recognition...")
        self.name = None
        self.drink = None
        self.name_received = False
        self.drink_received = False
        self.ask_follow_end_received = False
        
        self.start_pub.publish(True)  # 开始识别
        rospy.loginfo("[RecognizeFace] Published Start recognizing")

        name_sub = rospy.Subscriber('/recognized_name', String, self.name_cb)
        drink_sub = rospy.Subscriber('/recognized_drink', String, self.drink_cb)

        timeout = rospy.Time.now() + rospy.Duration(60.0)
        rate = rospy.Rate(10)
        while (not self.name_received or not self.drink_received) and rospy.Time.now() < timeout:
            rate.sleep()

        name_sub.unregister()
        drink_sub.unregister()
        self.start_pub.publish(False)  # 停止识别

        if self.name_received and self.drink_received:
            rospy.set_param('/guest_name', self.name)
            rospy.set_param('/guest_drink', self.drink)
            
            if self.drink in ['coke', 'sprite']:
                rospy.set_param('/grasp_select_mode', self.drink)
            else:
                rospy.set_param('/grasp_select_mode', 'random')
            # rospy.set_param('/grasp_select_mode', self.drink)
            rospy.loginfo(f"[RecognizeFace] Guest: {self.name}, wants: {self.drink}")

            rospy.loginfo("[RecognizeFace] Waiting for /ask_follow_end = True ...")
            ask_follow_sub = rospy.Subscriber('/ask_follow_end', Bool, self.ask_follow_cb)

            ask_timeout = rospy.Time.now() + rospy.Duration(50.0)
            while not self.ask_follow_end_received and rospy.Time.now() < ask_timeout:
                rate.sleep()

            ask_follow_sub.unregister()

            if self.ask_follow_end_received:
                rospy.loginfo("[RecognizeFace] Received /ask_follow_end = True.")
                return 'completed'
            else:
                rospy.logwarn("[RecognizeFace] Timeout waiting for /ask_follow_end.")
                return 'failed'
        else:
            rospy.logwarn("[RecognizeFace] Recognition failed or timed out.")
            return 'failed'

class FindEmptyChair(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['found', 'not_found'])

        self.control_pub = rospy.Publisher('/startyolo', Bool, queue_size=1)
        self.head_pub = rospy.Publisher('/head_controller/command', JointTrajectory, queue_size=1)        
        self.say_pub = rospy.Publisher('/the_word_to_say', String, queue_size=10)
        self.sub = None

        self.chair_detected_frames = 0
        self.chair_bbox = None

    def detection_callback(self, msg):
        # 遍历所有 bounding boxes，查找是否有 class == 'chair'
        for bbox in msg.bounding_boxes:
            if bbox.Class.lower() == 'chair':
                self.chair_detected_frames += 1
                self.chair_bbox = bbox
                rospy.loginfo("[FindEmptyChair] Chair detected (%d frames)", self.chair_detected_frames)
                return
        # 若该帧未检测到 chair，则重置
        self.chair_detected_frames = 0
        self.chair_bbox = None
    
    def look_at_chair(self, bbox):
        # 假设图像宽度为640像素（根据你的相机可调）
        image_width = 640
        cx = (bbox.xmin + bbox.xmax) / 2.0

        # 计算像素偏移（中心 - 椅子），假设最大视角±0.6弧度
        offset_pixel = cx - (image_width / 2.0)
        yaw_angle = -offset_pixel * 0.001671   # 负号：图像坐标系x右正，机器人左为正

        # 构造头部控制命令
        traj = JointTrajectory()
        traj.joint_names = ['head_1_joint', 'head_2_joint']
        point = JointTrajectoryPoint()
        point.positions = [yaw_angle, -0.5]  # 水平方向转头，俯仰-0.5
        point.time_from_start = rospy.Duration(1.0)
        traj.points.append(point)
        traj.header.stamp = rospy.Time.now()
        self.head_pub.publish(traj)
        rospy.loginfo(f"[FindEmptyChair] Moving head to yaw: {yaw_angle:.2f} rad")

    def execute(self, userdata):
        rospy.sleep(2.0)
        
        rospy.loginfo("[FindEmptyChair] Initialze head direction...")
        traj = JointTrajectory()
        traj.joint_names = ['head_1_joint', 'head_2_joint']
        point = JointTrajectoryPoint()
        point.positions = [0.0, -0.5]
        point.time_from_start = rospy.Duration(3.0)
        traj.points.append(point)
        traj.header.stamp = rospy.Time.now()
        self.head_pub.publish(traj)

        rospy.sleep(5.0)  # 等待头部完成动作
        
        rospy.loginfo("[FindEmptyChair] Activating YOLO chair detection...")
        self.control_pub.publish(True)
        rospy.sleep(3.0)  # 稍等 YOLO 启动

        self.chair_detected_frames = 0
        self.chair_bbox = None
        self.sub = rospy.Subscriber('/yolov5/detections', BoundingBoxes, self.detection_callback)

        timeout = rospy.Time.now() + rospy.Duration(10.0)
        rate = rospy.Rate(10)

        while rospy.Time.now() < timeout:
            if self.chair_detected_frames >= 5:  # 连续检测到 5 次 chair
                break
            rate.sleep()

        self.sub.unregister()
        self.control_pub.publish(False)
        rospy.loginfo("[FindEmptyChair] YOLO detection deactivated.")

        if self.chair_detected_frames >= 5 and self.chair_bbox is not None:
            self.look_at_chair(self.chair_bbox)
            seat_text = f"I am looking in the direction of an empty chair. Please take it! I will bring your drink in a moment."
            self.say_pub.publish(seat_text)
            rospy.sleep(8.0)
            return 'found'
        else:
            return 'not_found'

# class PickDrink(smach.State):
#     def __init__(self):
#         smach.State.__init__(self, outcomes=['succeeded', 'failed'])
#         self.pick_pub = rospy.Publisher('/start_picking', String, queue_size=1)
#         self.result_sub = rospy.Subscriber('/picking_done', Bool, self.done_callback)
#         self.done = False

#     def done_callback(self, msg):
#         if msg.data:
#             self.done = True

#     def execute(self, userdata):
#         # 获取饮料名称
#         if not rospy.has_param('/guest_drink'):
#             rospy.logwarn("[PickDrink] No guest drink found in ROS param server.")
#             return 'failed'
        
#         drink = rospy.get_param('/guest_drink')
#         rospy.loginfo(f"[PickDrink] Asking to pick drink: {drink}")

#         # 发送启动抓取命令
#         self.done = False
#         self.pick_pub.publish(String(drink))

#         # 等待抓取完成
#         timeout = rospy.Time.now() + rospy.Duration(30.0) 
#         rate = rospy.Rate(10)
#         while not self.done and rospy.Time.now() < timeout:
#             rate.sleep()

#         if self.done:
#             rospy.loginfo("[PickDrink] Drink picked successfully.")
#             return 'succeeded'
#         else:
#             rospy.logwarn("[PickDrink] Picking drink timed out or failed.")
#             return 'failed'

class DeliverDrink(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['delivered', 'failed'])

        # Arm trajectory action client
        self.arm_client = actionlib.SimpleActionClient('/arm_controller/follow_joint_trajectory', FollowJointTrajectoryAction)
        rospy.loginfo("[DeliverDrink] Waiting for arm_controller action server...")
        self.arm_client.wait_for_server()

        # Gripper控制
        self.gripper_pub = rospy.Publisher('/gripper_controller/command', JointTrajectory, queue_size=1)
        self.say_pub = rospy.Publisher('/the_word_to_say', String, queue_size=10)
        # 可选：订阅 deliver_finish 确认完成
        self.deliver_done = False
        self.sub = rospy.Subscriber('/deliver_finish', Bool, self.finish_callback)

    def finish_callback(self, msg):
        if msg.data:
            self.deliver_done = True

    def execute(self, userdata):
        rospy.loginfo("[DeliverDrink] Sending arm to delivery pose...")
        self.deliver_done = False

        # 创建目标轨迹
        goal = FollowJointTrajectoryGoal()
        traj = JointTrajectory()
        traj.joint_names = ['arm_1_joint','arm_2_joint','arm_3_joint','arm_4_joint','arm_5_joint','arm_6_joint','arm_7_joint']
        point = JointTrajectoryPoint()
        point.positions = [1.61, -0.93, -3.14, 1.83, -1.58, -0.62, 0.07]
        point.time_from_start = rospy.Duration(3.5)
        traj.points.append(point)
        goal.trajectory = traj
        goal.trajectory.header.stamp = rospy.Time.now() + rospy.Duration(0.5)

        # 发送轨迹
        self.arm_client.send_goal(goal)
        finished = self.arm_client.wait_for_result(rospy.Duration(10.0))
        if not finished:
            rospy.logwarn("[DeliverDrink] Arm movement timeout or failed.")
            return 'failed'
        

        guest_name = rospy.get_param('/guest_name', 'guest')
        guest_drink = rospy.get_param('/guest_drink', 'drink')
        serve_drink_text = f"{guest_name}, here is your {guest_drink}. Please hold it now and enjoy!"
        # serve_drink_text = f"Here is your {guest_drink}, {guest_name}."
        self.say_pub.publish(serve_drink_text)


        rospy.sleep(8)


        rospy.loginfo("[DeliverDrink] Opening gripper...")

        # 发布 gripper 打开命令（根据你实际 gripper controller 定义）
        gripper_traj = JointTrajectory()
        gripper_traj.joint_names = ['gripper_left_finger_joint', 'gripper_right_finger_joint']
        gripper_point = JointTrajectoryPoint()
        gripper_point.positions = [0.035, 0.035]  # fully open，根据实际情况调整
        gripper_point.time_from_start = rospy.Duration(2.0)
        gripper_traj.points.append(gripper_point)
        self.gripper_pub.publish(gripper_traj)
        rospy.sleep(2.5)  # 等待 gripper 打开
        # 等待 /deliver_finish 或固定延时
        self.deliver_done = True

        if self.deliver_done:
            rospy.loginfo("[DeliverDrink] Returning arm to home pose...")

            home_goal = FollowJointTrajectoryGoal()
            home_traj = JointTrajectory()
            home_traj.joint_names = ['arm_1_joint','arm_2_joint','arm_3_joint','arm_4_joint','arm_5_joint','arm_6_joint','arm_7_joint']
            home_point = JointTrajectoryPoint()
            home_point.positions = [0.2, -1.34, -0.2, 1.94, -1.57, 1.37, 0.0]  # 替换为你的 home 姿态
            home_point.time_from_start = rospy.Duration(3.0)
            home_traj.points.append(home_point)
            home_goal.trajectory = home_traj
            home_goal.trajectory.header.stamp = rospy.Time.now() + rospy.Duration(0.5)

            self.arm_client.send_goal(home_goal)
            self.arm_client.wait_for_result(rospy.Duration(10.0))

            rospy.loginfo("[DeliverDrink] Delivery succeeded and arm returned home.")
            return 'delivered'
        else:
            rospy.logwarn("[DeliverDrink] Delivery timeout or not confirmed.")
            return 'failed'

def main():
    rospy.init_node('tiago_party_state_machine')

    sm = smach.StateMachine(outcomes=['TASK_COMPLETED', 'TASK_FAILED'])

    with sm:
        rospy.loginfo("Adding LOCALIZE_START")
        smach.StateMachine.add('LOCALIZE_START', LocalizationState(),
                               transitions={'localized': 'NAV_TO_START',
                                            'failed': 'TASK_FAILED'})
        rospy.loginfo("Adding NAV_TO_START")
        smach.StateMachine.add('NAV_TO_START', NavigateToWaypoint('start_position'),
                               transitions={'succeeded': 'DETECT_PEOPLE',
                                            'failed': 'TASK_FAILED'})

        rospy.loginfo("Adding DETECT_PEOPLE")
        smach.StateMachine.add('DETECT_PEOPLE', DetectPeople(),
                               transitions={'two_detected': 'NAV_TO_GREETING',
                                            'not_detected': 'DETECT_PEOPLE'})

        smach.StateMachine.add('NAV_TO_GREETING', NavigateToWaypoint('greeting_position'),
                               transitions={'succeeded': 'RECOGNIZE_FACE',
                                            'failed': 'TASK_FAILED'})

        smach.StateMachine.add('RECOGNIZE_FACE', RecognizeFaceAndGreet(),
                               transitions={'completed': 'NAV_TO_OBSERVE',
                                            'failed': 'RECOGNIZE_FACE'})
        
        smach.StateMachine.add('NAV_TO_OBSERVE', NavigateToWaypoint('observation_position'),
                               transitions={'succeeded': 'FIND_CHAIR',
                                            'failed': 'TASK_FAILED'})

##################TEst for find and look at chair############
        smach.StateMachine.add('FIND_CHAIR', FindEmptyChair(),
                               transitions={'found': 'NAV_TO_DRINK',
                                            'not_found': 'FIND_CHAIR'})

        smach.StateMachine.add('NAV_TO_DRINK', NavigateToWaypoint('drink_table_position'),
                               transitions={'succeeded': 'PICK_DRINK',
                                            'failed': 'TASK_FAILED'})

        smach.StateMachine.add('PICK_DRINK', create_grasp_sub_sm(),
                                transitions={'succeeded':'ARM_HOME', 
                                             'aborted':'PICK_DRINK_2'})

        smach.StateMachine.add('PICK_DRINK_2', create_grasp_sub_sm(),
                                transitions={'succeeded':'ARM_HOME', 
                                             'aborted':'PICK_DRINK_3'})

        smach.StateMachine.add('PICK_DRINK_3', create_grasp_sub_sm(),
                                transitions={'succeeded':'ARM_HOME', 
                                             'aborted':'ARM_HOME'})

        smach.StateMachine.add('ARM_HOME', ReturnArmHome(),
                                transitions={'succeeded':'NAV_TO_DELIVERY', 
                                             'aborted':'TASK_FAILED'})
        

        smach.StateMachine.add('NAV_TO_DELIVERY', NavigateToWaypoint('delivery_position'),
                               transitions={'succeeded': 'DELIVER_DRINK',
                                            'failed': 'TASK_FAILED'})

        smach.StateMachine.add('DELIVER_DRINK', DeliverDrink(),
                               transitions={'delivered': 'NAV_TO_START',
                                            'failed': 'TASK_FAILED'})


    sis = smach_ros.IntrospectionServer('server_name', sm, '/SM_ROOT')
    sis.start()
    outcome = sm.execute()
    rospy.spin()




########Simple State Machine test only with localization and navigation#########
# def main():
#     rospy.init_node('tiago_party_state_machine')

#     sm = smach.StateMachine(outcomes=['done', 'failed'])
#     with sm:
#         smach.StateMachine.add('LOCALIZE', LocalizationState(),
#                                transitions={'localized': 'NAV',
#                                             'failed': 'failed'})
#         smach.StateMachine.add('NAV', NavigateToWaypoint('start_position'),
#                                transitions={'succeeded': 'done',
#                                             'failed': 'failed'})

#     sis = smach_ros.IntrospectionServer('server_name', sm, '/SM_ROOT')
#     sis.start()
#     outcome = sm.execute()
#     rospy.spin()


if __name__ == '__main__':
    main()