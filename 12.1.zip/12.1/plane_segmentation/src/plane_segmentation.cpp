#include <plane_segmentation/plane_segmentation.h>

PlaneSegmentation::PlaneSegmentation(
    const std::string& pointcloud_topic, 
    const std::string& base_frame) :
  pointcloud_topic_(pointcloud_topic),
  base_frame_(base_frame),
  is_cloud_updated_(false),
  table_centroid_computed_(false)   // ★ 新增：桌子中心点只算一次
{
}

PlaneSegmentation::~PlaneSegmentation()
{
}

bool PlaneSegmentation::initalize(ros::NodeHandle& nh)
{
  // load rosparams
  std::vector<float> pre_pass_limits;
  std::vector<float> seg_pass_limits;
  if (!ros::param::get("pre_pass_filter", pre_pass_limits))
  {
    ROS_ERROR("Failed to get param pre_pass_filter");
    return false;
  }
  if (!ros::param::get("seg_pass_filter", seg_pass_limits))
  {
    ROS_ERROR("Failed to get param seg_pass_filter");
    return false;
  }
  if (!ros::param::get("ransac_threshold", ransac_thresh_))
  {
    ROS_ERROR("Failed to get param ransac_threshold");
    return false;
  }

  pre_pass_low_  = pre_pass_limits[0];
  pre_pass_high_ = pre_pass_limits[1];
  seg_pass_low_  = seg_pass_limits[0];
  seg_pass_high_ = seg_pass_limits[1];

  // subscribe to input point cloud
  point_cloud_sub_ = nh.subscribe(pointcloud_topic_, 10,
                                  &PlaneSegmentation::cloudCallback, this);

  // advertise the pointcloud of the table plane
  plane_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>("/table_point_cloud", 1);

  // advertise the pointcloud of the remaining points (objects)
  objects_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>("/objects_point_cloud", 1);

  // ★ 新增：发布桌子中心点（latched），话题名单独用 /table_centroid
  table_centroid_pub_ = nh.advertise<geometry_msgs::PointStamped>("/table_centroid", 1, true);

  // init internal pointclouds
  raw_cloud_.reset(new PointCloud);
  preprocessed_cloud_.reset(new PointCloud);
  plane_cloud_.reset(new PointCloud);
  objects_cloud_.reset(new PointCloud);

  return true;
}

void PlaneSegmentation::update(const ros::Time& time)
{
  // update as soon as new pointcloud is available
  if (!is_cloud_updated_)
    return;

  is_cloud_updated_ = false;

  // 1) preprocessing
  if(!preProcessCloud(raw_cloud_, preprocessed_cloud_))
    return;

  // 2) plane / objects segmentation
  if(!segmentCloud(preprocessed_cloud_, plane_cloud_, objects_cloud_))
    return;

  // 3) ★ 只在第一次成功分割出 plane_cloud_ 时计算桌子的中心点，并发布一次
  if (!table_centroid_computed_ && plane_cloud_ && !plane_cloud_->empty())
  {
    Eigen::Vector4f centroid;
    pcl::compute3DCentroid(*plane_cloud_, centroid);

    geometry_msgs::PointStamped centroid_msg;
    centroid_msg.header.frame_id = base_frame_;  // 桌面是在 base_frame_ 下
    centroid_msg.header.stamp = time;
    centroid_msg.point.x = centroid[0];
    centroid_msg.point.y = centroid[1];
    centroid_msg.point.z = centroid[2];

    table_centroid_pub_.publish(centroid_msg);
    table_centroid_computed_ = true;

    ROS_INFO_STREAM("Table centroid computed once at ("
                    << centroid[0] << ", " << centroid[1] << ", " << centroid[2]
                    << ") and published on /table_centroid.");
  }

  // 4) publish both pointclouds

  sensor_msgs::PointCloud2 plane_cloud_msg;
  sensor_msgs::PointCloud2 objects_cloud_msg;

  pcl::toROSMsg(*plane_cloud_, plane_cloud_msg);
  pcl::toROSMsg(*objects_cloud_, objects_cloud_msg);

  // 建议设置 frame_id & stamp，方便在 RViz 里使用
  plane_cloud_msg.header.frame_id   = base_frame_;
  plane_cloud_msg.header.stamp      = time;
  objects_cloud_msg.header.frame_id = base_frame_;
  objects_cloud_msg.header.stamp    = time;

  plane_cloud_pub_.publish(plane_cloud_msg);
  objects_cloud_pub_.publish(objects_cloud_msg);
}

bool PlaneSegmentation::preProcessCloud(CloudPtr& input, CloudPtr& output)
{
  // Goal: Subsample and Filter the pointcloud

  // 1) VoxelGrid 下采样
  CloudPtr ds_cloud(new PointCloud);            // downsampled pointcloud
  pcl::VoxelGrid<PointT> voxel_filter;
  voxel_filter.setInputCloud(input);
  voxel_filter.setLeafSize(0.01f, 0.01f, 0.01f); // 根据需要调整
  voxel_filter.filter(*ds_cloud);

  // 2) Transform the point cloud to the base_frame of the robot
  CloudPtr transf_cloud(new PointCloud);        // transformed pointcloud (expressed in base frame)

  ds_cloud->header = input->header;

  try
  {
    tfListener_.waitForTransform(base_frame_, ds_cloud->header.frame_id,
                                 ros::Time(0), ros::Duration(1.0));
  }
  catch (tf::TransformException& ex)
  {
    ROS_WARN_STREAM("TF waitForTransform failed: " << ex.what());
    return false;
  }

  pcl_ros::transformPointCloud(base_frame_, ros::Time(0),
                               *ds_cloud, ds_cloud->header.frame_id,
                               *transf_cloud, tfListener_);

  // 3) PassThrough 滤除地面以下/过高的点
  pcl::PassThrough<PointT> pass;
  pass.setInputCloud(transf_cloud);
  pass.setFilterFieldName("z");
  pass.setFilterLimits(pre_pass_low_, pre_pass_high_);
  pass.filter(*output);

  // ROS_INFO_STREAM("Preprocessed cloud size: " << output->size());

  return true;
}

bool PlaneSegmentation::segmentCloud(CloudPtr& input,
                                     CloudPtr& plane_cloud,
                                     CloudPtr& objects_cloud)
{
  // Goal: Remove every point that is not an object from the objects_cloud cloud

  // 1. Segment the plane using RANSAC
  pcl::SACSegmentation<PointT> seg;
  pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
  pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);

  seg.setOptimizeCoefficients(true);
  seg.setModelType(pcl::SACMODEL_PLANE);
  seg.setMethodType(pcl::SAC_RANSAC);
  seg.setDistanceThreshold(ransac_thresh_);
  seg.setProbability(0.99);
  seg.setInputCloud(input);
  seg.segment(*inliers, *coefficients);

  if (inliers->indices.empty())
  {
    ROS_WARN("Plane segmentation failed. No inliers found.");
    return false;
  }

  // 2. Extract plane points (table)
  pcl::ExtractIndices<PointT> extract;
  extract.setInputCloud(input);
  extract.setIndices(inliers);

  extract.setNegative(false); // 提取 inliers
  extract.filter(*plane_cloud);

  // 3. Extract non-plane points (objects)
  extract.setNegative(true); // 提取 outliers
  extract.filter(*objects_cloud);

  // 4. Convert the plane parameters to normal vector n and distance d
  if(coefficients->values.size() < 4)
    return false;

  Eigen::Vector3f n(coefficients->values[0],
                    coefficients->values[1],
                    coefficients->values[2]);
  float d = coefficients->values[3];

  // 5. Build rotation from table normal to world z-axis
  Eigen::Vector3f z_axis(0.0, 0.0, 1.0);
  Eigen::Quaternionf Q_plane_base = Eigen::Quaternionf::FromTwoVectors(n, z_axis);

  // 6. Construct translation
  Eigen::Vector3f t_plane_base = d * n;

  // 7. Create affine transform T_plane_base
  Eigen::Affine3f T_plane_base = Eigen::Affine3f::Identity();
  T_plane_base.rotate(Q_plane_base.toRotationMatrix());
  T_plane_base.translate(t_plane_base);

  // 8. Transform objects_cloud to plane-aligned frame
  CloudPtr transf_cloud(new PointCloud);
  pcl::transformPointCloud(*objects_cloud, *transf_cloud, T_plane_base);

  // 9. Filter objects in plane frame: keep z in [seg_pass_low_, seg_pass_high_]
  pcl::PassThrough<PointT> pass;
  pass.setInputCloud(transf_cloud);
  pass.setFilterFieldName("z");
  pass.setFilterLimits(seg_pass_low_, seg_pass_high_);

  CloudPtr filtered_cloud(new PointCloud);
  pass.filter(*filtered_cloud);

  // 10. Transform back to base frame
  pcl::transformPointCloud(*filtered_cloud, *objects_cloud, T_plane_base.inverse());

  return true;
}

void PlaneSegmentation::cloudCallback(const sensor_msgs::PointCloud2ConstPtr &msg)
{
  // convert ros msg to pcl raw_cloud
  is_cloud_updated_ = true;
  pcl::fromROSMsg(*msg, *raw_cloud_);
}

