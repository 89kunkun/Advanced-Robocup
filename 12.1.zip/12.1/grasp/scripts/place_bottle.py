#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math

import rospy
import moveit_commander
import tf.transformations as tft
import numpy as np

from geometry_msgs.msg import PoseStamped, PointStamped
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from sensor_msgs.msg import JointState
from moveit_commander import MoveGroupCommander, PlanningSceneInterface


class BottlePlacer(object):
    def __init__(self):
        rospy.init_node("place_bottle_on_table")
        rospy.loginfo("[INIT] place_bottle_on_table node started")

        # ==== MoveIt 初始化 ====
        rospy.loginfo("[INIT] Initializing MoveIt commander...")
        moveit_commander.roscpp_initialize(sys.argv)

        try:
            self.arm_group = MoveGroupCommander("arm")
        except Exception as e:
            rospy.logfatal("[INIT] Failed to create MoveGroupCommander('arm'): %s", str(e))
            raise

        # 和你 C++ Grasper 尽量保持一致
        self.arm_group.set_pose_reference_frame("base_footprint")
        self.arm_group.set_end_effector_link("gripper_link")
        self.arm_group.set_goal_tolerance(0.03)
        self.arm_group.set_max_velocity_scaling_factor(0.3)
        self.arm_group.set_max_acceleration_scaling_factor(0.1)
        self.arm_group.set_planning_time(15.0)
        self.arm_group.set_start_state_to_current_state()

        rospy.loginfo(
            "[INIT] MoveGroup 'arm' configured. Ref frame: %s, EE: %s",
            self.arm_group.get_planning_frame(),
            self.arm_group.get_end_effector_link()
        )

        # 规划场景（现在没用到障碍，但先建好）
        self.planning_scene_interface = PlanningSceneInterface()
        rospy.loginfo("[INIT] PlanningSceneInterface created")

        # 发布器：和 C++ 一致
        self.gripper_pub = rospy.Publisher(
            "/gripper_controller/command", JointTrajectory, queue_size=1
        )
        self.torso_pub = rospy.Publisher(
            "/torso_controller/command", JointTrajectory, queue_size=1
        )
        rospy.loginfo("[INIT] Publishers created: /gripper_controller/command, /torso_controller/command")

        # 等待 joint_states
        rospy.loginfo("[INIT] Waiting for joint_states...")
        rospy.wait_for_message("joint_states", JointState)
        rospy.sleep(0.5)
        rospy.loginfo("[INIT] joint_states received")

        # 可选：先抬一点 torso（和你之前的逻辑一致）
        self.raise_torso(0.20)

        # === 读取桌子中心点 ===
        rospy.loginfo("[PLACE] Waiting for /table_centroid ...")
        table_centroid = rospy.wait_for_message("/table_centroid", PointStamped)
        rospy.loginfo(
            "[PLACE] Received table centroid: (%.3f, %.3f, %.3f) in frame [%s]",
            table_centroid.point.x,
            table_centroid.point.y,
            table_centroid.point.z,
            table_centroid.header.frame_id,
        )

        # 打印相对机器人位置：前/后、左/右、高度
        cx = table_centroid.point.x
        cy = table_centroid.point.y
        cz = table_centroid.point.z

        front_back = "前方" if cx >= 0 else "后方"
        left_right = "左边" if cy >= 0 else "右边"

        rospy.loginfo(
            "[PLACE] 桌子中心点大约在：机器人%s %.1f cm，%s %.1f cm，高度 %.1f cm",
            front_back, abs(cx) * 100.0,
            left_right, abs(cy) * 100.0,
            cz * 100.0
        )

        # === 执行放置动作 ===
        rospy.loginfo("[PLACE] Starting place_bottle() procedure")
        try:
            self.place_bottle(table_centroid)
        except Exception as e:
            rospy.logfatal("[PLACE] Exception in place_bottle(): %s", str(e))

        rospy.loginfo("[END] Bottle placing finished. Shutting down MoveIt.")
        moveit_commander.roscpp_shutdown()

    # ================== torso 控制 ==================

    def raise_torso(self, height=0.20):
        """
        类似 grasp_try 里的 moveTorso：通过 /torso_controller/command 控制 torso_lift_joint
        """
        rospy.loginfo("[TORSO] Raising torso to %.2f m (optional)...", height)

        traj = JointTrajectory()
        traj.joint_names = ["torso_lift_joint"]

        pt = JointTrajectoryPoint()
        pt.positions = [height]
        pt.time_from_start = rospy.Duration(3.0)
        traj.points.append(pt)

        rospy.loginfo(
            "[TORSO] Sending torso_lift_joint to %.3f m via /torso_controller/command ...",
            height
        )

        # 多发几次，和你对 gripper 的用法类似
        for i in range(3):
            self.torso_pub.publish(traj)
            rospy.loginfo("[TORSO] Published torso command #%d", i + 1)
            rospy.sleep(0.2)

        rospy.loginfo("[TORSO] Torso command sent (no direct feedback here, check joint_states).")

    # ================== 关键放置逻辑 ==================

    def place_bottle(self, centroid_msg: PointStamped):
        """
        已经抓在手里的瓶子 -> 放到桌子中心上方。
        """
        rospy.loginfo("[PLACE] Entering place_bottle()")

        cx = centroid_msg.point.x
        cy = centroid_msg.point.y
        cz = centroid_msg.point.z
        frame_id = centroid_msg.header.frame_id  # 通常是 base_footprint

        rospy.loginfo(
            "[PLACE] Target table centroid in %s: (%.3f, %.3f, %.3f)",
            frame_id, cx, cy, cz
        )

        # 高度参数
        pre_place_height = 0.15   # 桌面上方 15cm
        place_height     = 0.05   # 放置时，桌面上方 5cm

        rospy.loginfo(
            "[PLACE] pre_place_height = %.3f, place_height = %.3f",
            pre_place_height, place_height
        )

        # 当前末端姿态，沿用当前 orientation，避免 IK 出问题
        current_pose = self.arm_group.get_current_pose(self.arm_group.get_end_effector_link())
        rospy.loginfo(
            "[PLACE] Current EE pose (frame %s): pos(%.3f, %.3f, %.3f), "
            "ori(%.3f, %.3f, %.3f, %.3f)",
            current_pose.header.frame_id,
            current_pose.pose.position.x,
            current_pose.pose.position.y,
            current_pose.pose.position.z,
            current_pose.pose.orientation.x,
            current_pose.pose.orientation.y,
            current_pose.pose.orientation.z,
            current_pose.pose.orientation.w,
        )

        # ---------- 1. 预放置位姿：桌子中心正上方 ----------
        pre_place_pose = PoseStamped()
        pre_place_pose.header.frame_id = frame_id
        pre_place_pose.header.stamp = rospy.Time.now()
        pre_place_pose.pose.position.x = cx
        pre_place_pose.pose.position.y = cy
        pre_place_pose.pose.position.z = cz + pre_place_height
        # 使用当前抓的姿态
        pre_place_pose.pose.orientation = current_pose.pose.orientation

        rospy.loginfo(
            "[PLACE] Pre-place target pose in %s: pos(%.3f, %.3f, %.3f), "
            "ori(%.3f, %.3f, %.3f, %.3f)",
            pre_place_pose.header.frame_id,
            pre_place_pose.pose.position.x,
            pre_place_pose.pose.position.y,
            pre_place_pose.pose.position.z,
            pre_place_pose.pose.orientation.x,
            pre_place_pose.pose.orientation.y,
            pre_place_pose.pose.orientation.z,
            pre_place_pose.pose.orientation.w,
        )

        rospy.loginfo("[PLACE] Moving arm to pre-place pose above table...")
        if not self.move_arm_to_target(pre_place_pose):
            rospy.logerr("[PLACE] Failed to reach pre-place pose. Aborting place_bottle().")
            return
        rospy.loginfo("[PLACE] Reached pre-place pose.")
        rospy.sleep(2.0)

        # ---------- 2. 往下“走 10 cm”：改成用 go() 规划到目标 pose ----------
        down_distance = pre_place_height - place_height
        rospy.loginfo(
            "[PLACE] Moving arm straight down to place height. Down distance = %.3f m",
            down_distance
        )
        if not self.move_ee_straight_direction(0.0, 0.0, -1.0, down_distance):
            rospy.logerr("[PLACE] Failed to move down to place pose. Aborting.")
            return
        rospy.sleep(1.0)

        # ---------- 3. 打开夹爪，放下瓶子 ----------
        rospy.loginfo("[PLACE] Opening gripper to release bottle...")
        self.open_gripper()
        rospy.sleep(1.0)

        # ---------- 4. 直线上抬一点，离开物体 ----------
        rospy.loginfo("[PLACE] Lifting arm up a bit after placing...")
        if not self.move_ee_straight_direction(0.0, 0.0, 1.0, 0.10):
            rospy.logwarn("[PLACE] Failed to lift up after placing.")
        rospy.sleep(1.0)

    # ====== MoveIt 封装函数 ======

    def move_arm_to_target(self, target_pose_stamped: PoseStamped) -> bool:
        """
        对应 C++ 的 Grasper::moveArmToTarget
        """
        rospy.loginfo("[ARM] move_arm_to_target() called.")
        rospy.loginfo(
            "[ARM] Target pose in %s: pos(%.3f, %.3f, %.3f), ori(%.3f, %.3f, %.3f, %.3f)",
            target_pose_stamped.header.frame_id,
            target_pose_stamped.pose.position.x,
            target_pose_stamped.pose.position.y,
            target_pose_stamped.pose.position.z,
            target_pose_stamped.pose.orientation.x,
            target_pose_stamped.pose.orientation.y,
            target_pose_stamped.pose.orientation.z,
            target_pose_stamped.pose.orientation.w,
        )

        self.arm_group.set_pose_target(target_pose_stamped)
        self.arm_group.set_max_velocity_scaling_factor(0.2)
        self.arm_group.set_max_acceleration_scaling_factor(0.1)

        rospy.loginfo("[ARM] Calling arm_group.go(wait=True)...")
        success = self.arm_group.go(wait=True)
        rospy.loginfo("[ARM] arm_group.go() finished, success=%s", str(success))

        self.arm_group.stop()
        self.arm_group.clear_pose_targets()
        rospy.loginfo("[ARM] arm_group.stop() and clear_pose_targets() called")

        if not success:
            rospy.logerr("[ARM] move_arm_to_target() failed (go() returned False)")
            return False

        return True

    def move_ee_straight_direction(self, dx, dy, dz, distance) -> bool:
        """
        原本是 Cartesian path：
            compute_cartesian_path + execute
        现在改成：
            计算目标 pose -> 用 go() 再规划一次。
        这样完全绕开你当前 MoveIt 版本的 compute_cartesian_path/controller 兼容问题。
        """
        rospy.loginfo(
            "[CART-FAKE] move_ee_straight_direction(dx=%.3f, dy=%.3f, dz=%.3f, dist=%.3f)",
            dx, dy, dz, distance
        )

        direction = np.array([dx, dy, dz], dtype=float)
        norm = np.linalg.norm(direction)
        if norm < 1e-6:
            rospy.logerr("[CART-FAKE] Direction vector is zero! Aborting.")
            return False
        direction /= norm
        rospy.loginfo("[CART-FAKE] Normalized direction: (%.3f, %.3f, %.3f)",
                      direction[0], direction[1], direction[2])

        current_pose = self.arm_group.get_current_pose(self.arm_group.get_end_effector_link())
        start = current_pose.pose
        rospy.loginfo(
            "[CART-FAKE] Current EE pose: pos(%.3f, %.3f, %.3f)",
            start.position.x, start.position.y, start.position.z
        )

        target = PoseStamped()
        target.header = current_pose.header
        target.pose = current_pose.pose
        target.pose.position.x += direction[0] * distance
        target.pose.position.y += direction[1] * distance
        target.pose.position.z += direction[2] * distance

        rospy.loginfo(
            "[CART-FAKE] Target EE pose: pos(%.3f, %.3f, %.3f)",
            target.pose.position.x,
            target.pose.position.y,
            target.pose.position.z
        )

        # 直接用 go() 让 MoveIt 自己规划这小段路
        return self.move_arm_to_target(target)

    # ========= gripper 打开 =========

    def open_gripper(self):
        """
        和你 C++ closeGripper 结构类似，只是把位置改成“张开”。
        """
        traj = JointTrajectory()
        traj.joint_names = [
            "gripper_left_finger_joint",
            "gripper_right_finger_joint"
        ]

        pt = JointTrajectoryPoint()
        pt.positions = [0.04, 0.04]  # 视情况调大/调小
        pt.time_from_start = rospy.Duration(3.0)
        traj.points.append(pt)

        traj.header.stamp = rospy.Time.now() + rospy.Duration(0.2)

        for i in range(3):
            self.gripper_pub.publish(traj)
            rospy.loginfo("[GRIPPER] Publish open command #%d", i + 1)
            rospy.sleep(0.1)


if __name__ == "__main__":
    try:
        BottlePlacer()
    except rospy.ROSInterruptException:
        pass

