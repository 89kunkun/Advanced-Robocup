#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>

#include <visualization_msgs/MarkerArray.h>
#include <geometry_msgs/Point.h>

#include <Eigen/Dense>
#include <limits>
#include <algorithm>
#include <cmath>

#include <grasp/pca_utils.h>

class PCANode
{
public:
  explicit PCANode(ros::NodeHandle& nh)
  {
    nh.param<std::string>("input_topic", input_topic_, std::string("/cloud_labeled"));
    nh.param("target_label", target_label_, 1);
    nh.param("run_once", run_once_, false);

    nh.param("axis_scale", axis_scale_, 0.25);
    nh.param("axis_radius", axis_radius_, 0.01);

    // 判断“竖直”的阈值：|long·up| > threshold -> 竖直
    nh.param("vertical_cos_threshold", vertical_cos_threshold_, 0.8);

    // 仅用于输出“躺/立”的信息（不是构造轴的逻辑）
    nh.param("horizontal_cos_threshold", horizontal_cos_threshold_, 0.4);

    sub_ = nh.subscribe(input_topic_, 1, &PCANode::cb, this);

    // 发布 MarkerArray topic: /pca_node/pca_axes
    marker_pub_ = nh.advertise<visualization_msgs::MarkerArray>("pca_axes", 1, true);

    ROS_INFO("pca_node listening: %s (target_label=%d)", input_topic_.c_str(), target_label_);
    ROS_INFO("vertical_cos_threshold=%.3f, horizontal_cos_threshold=%.3f",
             vertical_cos_threshold_, horizontal_cos_threshold_);
  }

private:
  void cb(const sensor_msgs::PointCloud2ConstPtr& msg)
  {
    if (run_once_ && done_) return;

    // 1) 点云读取
    pcl::PointCloud<pcl::PointXYZL> cloud;
    pcl::fromROSMsg(*msg, cloud);
    if (cloud.empty()) return;

    // 2) 按 label 过滤
    std::vector<pcl::PointXYZL> target_pts;
    target_pts.reserve(cloud.size());
    for (const auto& p : cloud.points)
    {
      if ((int)p.label == target_label_)
        target_pts.push_back(p);
    }
    if (target_pts.empty())
    {
      ROS_WARN("No points with label %d", target_label_);
      return;
    }

    // 3) PCA（只用它来得到“最长轴方向”以及质心/特征值等）
    PCAResult r;
    if (!computePCAFromLabeledPoints(target_pts, r))
    {
      ROS_ERROR("PCA failed");
      return;
    }

    r.axis_long.normalize();
    r.axis_mid.normalize();
    r.axis_thin.normalize();

    // 4) 用“最长轴 vs 世界 up”判断：竖直 or 水平
    const Eigen::Vector3d up(0, 0, 1);
    const Eigen::Vector3d down(0, 0, -1);
    const Eigen::Vector3d left(0, 1, 0);

    Eigen::Vector3d axis_long_pca = r.axis_long.normalized();
    double cos_to_up = std::fabs(axis_long_pca.dot(up));
    bool is_vertical = (cos_to_up > vertical_cos_threshold_);

    Eigen::Vector3d axis_long, axis_mid, axis_thin;

    if (is_vertical)
    {
      // ==============================
      // 情况 A：最长轴接近竖直（⊥ 地面）
      // 你要求：
      // long = (0,0,-1)
      // mid  = (0,1,0)
      // thin = long × mid
      // ==============================
      axis_long = down;                 // (0,0,-1)
      axis_mid  = left;                 // (0,1,0)
      axis_thin = axis_long.cross(axis_mid); // (-Z)×(+Y) = +X

      axis_thin.normalize();

      ROS_WARN("[MODE] VERTICAL: long=(0,0,-1), mid=(0,1,0), thin=long×mid=(%.3f,%.3f,%.3f)",
               axis_thin.x(), axis_thin.y(), axis_thin.z());
    }
    else
    {
      // ==============================
      // 情况 B：最长轴接近水平（∥ 地面）
      // 你要求：
      // thin = (0,0,-1)
      // long: 确保 z=0 (投影到地面)
      // mid = thin × long
      // ==============================
      axis_thin = down; // (0,0,-1)

      // long: 用 PCA 长轴投影到 XY 平面
      axis_long = axis_long_pca;
      axis_long.z() = 0.0;

      if (axis_long.norm() < 1e-6)
      {
        // 极端退化：PCA long 几乎竖直但却被判成水平（阈值太松或噪声）
        // 给一个默认水平前向
        axis_long = Eigen::Vector3d(1, 0, 0);
      }
      axis_long.normalize();

      axis_mid = axis_thin.cross(axis_long); // (-Z)×(long_xy)
      if (axis_mid.norm() < 1e-6)
      {
        // 再退化：给默认左向
        axis_mid = Eigen::Vector3d(0, 1, 0);
      }
      axis_mid.normalize();

      ROS_WARN("[MODE] HORIZONTAL: thin=(0,0,-1), long=PCA@XY=(%.3f,%.3f,%.3f), mid=thin×long=(%.3f,%.3f,%.3f)",
               axis_long.x(), axis_long.y(), axis_long.z(),
               axis_mid.x(), axis_mid.y(), axis_mid.z());
    }

    // 5) 写回“最终用于输出/可视化的三轴”
    r.axis_long = axis_long;
    r.axis_mid  = axis_mid;
    r.axis_thin = axis_thin;

    // 6) 计算“沿轴投影跨度”（尺寸）
    double len_long = 0, len_mid = 0, len_thin = 0;
    computeAxisLengths(target_pts, r, len_long, len_mid, len_thin);

    // 7) 输出
    ROS_INFO("------------------------------------------------------------");
    ROS_INFO("Frame: %s", msg->header.frame_id.c_str());
    ROS_INFO("Centroid: [x=%.3f, y=%.3f, z=%.3f]", r.centroid.x(), r.centroid.y(), r.centroid.z());

    ROS_INFO("Axis LONG (red)  : [x=%.3f, y=%.3f, z=%.3f]", r.axis_long.x(), r.axis_long.y(), r.axis_long.z());
    ROS_INFO("Axis MID  (green): [x=%.3f, y=%.3f, z=%.3f]", r.axis_mid.x(),  r.axis_mid.y(),  r.axis_mid.z());
    ROS_INFO("Axis THIN (blue) : [x=%.3f, y=%.3f, z=%.3f]", r.axis_thin.x(), r.axis_thin.y(), r.axis_thin.z());

    ROS_INFO("Axis lengths (projection span): long=%.3f, mid=%.3f, thin=%.3f",
             len_long, len_mid, len_thin);

    // 仅作为信息输出：用最终 long 与 up 的夹角判断躺/立
    double cos_long_up_final = std::fabs(r.axis_long.dot(up));
    ROS_INFO("cos(angle(long_final, +Z(up))) = %.3f", cos_long_up_final);
    if (cos_long_up_final < horizontal_cos_threshold_)
      ROS_WARN("[JUDGE] HORIZONTAL (lying on table)");
    else
      ROS_WARN("[JUDGE] VERTICAL (standing)");

    // 8) 发布 RViz Marker
    publishMarkers(r, msg->header.frame_id);

    done_ = true;
  }

  static void computeAxisLengths(const std::vector<pcl::PointXYZL>& pts,
                                 const PCAResult& r,
                                 double& len_long,
                                 double& len_mid,
                                 double& len_thin)
  {
    auto proj_span = [&](const Eigen::Vector3d& axis_unit) -> double {
      double min_p =  std::numeric_limits<double>::infinity();
      double max_p = -std::numeric_limits<double>::infinity();
      for (const auto& p : pts)
      {
        Eigen::Vector3d v(p.x, p.y, p.z);
        double t = v.dot(axis_unit);
        min_p = std::min(min_p, t);
        max_p = std::max(max_p, t);
      }
      return max_p - min_p;
    };

    Eigen::Vector3d aL = r.axis_long.normalized();
    Eigen::Vector3d aM = r.axis_mid.normalized();
    Eigen::Vector3d aT = r.axis_thin.normalized();

    len_long = proj_span(aL);
    len_mid  = proj_span(aM);
    len_thin = proj_span(aT);
  }

  void publishMarkers(const PCAResult& r, const std::string& cloud_frame)
  {
    auto make_arrow =
        [&](int id,
            const Eigen::Vector3d& start,
            const Eigen::Vector3d& dir,
            float cr, float cg, float cb)
    {
      visualization_msgs::Marker m;
      m.header.frame_id = cloud_frame;
      m.header.stamp = ros::Time::now();
      m.ns = "pca_axes";
      m.id = id;
      m.type = visualization_msgs::Marker::ARROW;
      m.action = visualization_msgs::Marker::ADD;

      geometry_msgs::Point p0, p1;
      p0.x = start.x(); p0.y = start.y(); p0.z = start.z();
      Eigen::Vector3d end = start + dir.normalized() * axis_scale_;
      p1.x = end.x();   p1.y = end.y();   p1.z = end.z();

      m.points.push_back(p0);
      m.points.push_back(p1);

      m.scale.x = axis_radius_;
      m.scale.y = axis_radius_ * 2.0;
      m.scale.z = axis_radius_ * 3.0;

      m.color.a = 1.0;
      m.color.r = cr; m.color.g = cg; m.color.b = cb;

      m.lifetime = ros::Duration(0);
      return m;
    };

    visualization_msgs::MarkerArray arr;
    Eigen::Vector3d c = r.centroid;

    // long=红 mid=绿 thin=蓝
    arr.markers.push_back(make_arrow(0, c, r.axis_long, 1.0f, 0.0f, 0.0f));
    arr.markers.push_back(make_arrow(1, c, r.axis_mid,  0.0f, 1.0f, 0.0f));
    arr.markers.push_back(make_arrow(2, c, r.axis_thin, 0.0f, 0.0f, 1.0f));

    marker_pub_.publish(arr);
  }

private:
  ros::Subscriber sub_;
  ros::Publisher marker_pub_;

  std::string input_topic_;
  int target_label_{1};
  bool run_once_{false};
  bool done_{false};

  double axis_scale_{0.25};
  double axis_radius_{0.01};

  double vertical_cos_threshold_{0.8};
  double horizontal_cos_threshold_{0.4};
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "pca_node");
  ros::NodeHandle nh("~");
  PCANode node(nh);
  ros::spin();
  return 0;
}

