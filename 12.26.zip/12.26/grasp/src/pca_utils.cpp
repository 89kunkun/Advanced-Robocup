#include <grasp/pca_utils.h>

#include <cmath>

bool computePCAFromLabeledPoints(const std::vector<pcl::PointXYZL>& pts, PCAResult& out)
{
  if (pts.empty()) return false;

  // centroid
  Eigen::Vector3d c(0, 0, 0);
  for (const auto& p : pts)
  {
    c += Eigen::Vector3d(p.x, p.y, p.z);
  }
  c /= static_cast<double>(pts.size());
  out.centroid = c;

  // build matrix
  const size_t N = pts.size();
  Eigen::MatrixXd M(N, 3);
  for (size_t i = 0; i < N; ++i)
  {
    M(i, 0) = pts[i].x;
    M(i, 1) = pts[i].y;
    M(i, 2) = pts[i].z;
  }

  // de-mean
  Eigen::Vector3d mean = M.colwise().mean();
  for (size_t i = 0; i < N; ++i)
  {
    M.row(i) -= mean.transpose();
  }

  // covariance & eig
  Eigen::Matrix3d cov = (M.transpose() * M) / static_cast<double>(N);
  Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> es(cov);
  if (es.info() != Eigen::Success) return false;

  out.eigvals = es.eigenvalues();         // ascending
  Eigen::Matrix3d eigvecs = es.eigenvectors();

  out.axis_thin = eigvecs.col(0);
  out.axis_mid  = eigvecs.col(1);
  out.axis_long = eigvecs.col(2);

  Eigen::Vector3d world_z(0, 0, 1);
  out.cos_angle_long_vs_world_z = std::fabs(out.axis_long.dot(world_z));
  out.is_horizontal = (out.cos_angle_long_vs_world_z < 0.4);

  return true;
}

