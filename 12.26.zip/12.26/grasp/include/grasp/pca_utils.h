#pragma once

#include <Eigen/Dense>
#include <vector>
#include <pcl/point_types.h>

// Result container for PCA analysis
struct PCAResult
{
  Eigen::Vector3d centroid;                 // centroid of input points
  Eigen::Vector3d eigvals;                  // eigenvalues (ascending): thin, mid, long
  Eigen::Vector3d axis_thin;                // eigenvector for smallest eigenvalue
  Eigen::Vector3d axis_mid;                 // eigenvector for middle eigenvalue
  Eigen::Vector3d axis_long;                // eigenvector for largest eigenvalue
  double cos_angle_long_vs_world_z = 0.0;   // |dot(axis_long, [0 0 1])|
  bool is_horizontal = false;               // heuristic judgement
};

// Compute PCA from labeled points (or any point list with x/y/z fields).
// Returns false if pts empty or eig solve fails.
bool computePCAFromLabeledPoints(const std::vector<pcl::PointXYZL>& pts, PCAResult& out);

