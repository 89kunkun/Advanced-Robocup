#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import moveit_commander

from geometry_msgs.msg import PointStamped, Pose
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class BottlePlacer(object):
    def __init__(self):
        rospy.init_node("place_bottle_on_table")
        rospy.loginfo("[INIT] place_bottle_on_table node started")

        # ========== MoveIt 初始化 ==========
        moveit_commander.roscpp_initialize([])
        self.arm = moveit_commander.MoveGroupCommander("arm")

        self.arm.set_pose_reference_frame("base_footprint")
        self.arm.set_end_effector_link("gripper_link")
        self.arm.set_goal_tolerance(0.02)
        self.arm.set_max_velocity_scaling_factor(0.25)
        self.arm.set_max_acceleration_scaling_factor(0.15)
        self.arm.set_planning_time(10.0)
        self.arm.allow_replanning(True)
        self.arm.set_num_planning_attempts(5)

        rospy.loginfo("[INIT] MoveGroup 'arm' ready. Ref frame: %s, EE: %s",
                      self.arm.get_planning_frame(),
                      self.arm.get_end_effector_link())

        # ========== Publishers ==========
        self.gripper_pub = rospy.Publisher(
            "/gripper_controller/command",
            JointTrajectory,
            queue_size=1
        )
        self.torso_pub = rospy.Publisher(
            "/torso_controller/command",
            JointTrajectory,
            queue_size=1
        )

        # 高度参数
        self.pre_height     = rospy.get_param("~pre_height",     0.15)
        self.place_offset   = rospy.get_param("~place_offset",   0.05)
        self.retreat_height = rospy.get_param("~retreat_height", 0.20)

        rospy.loginfo("[PARAM] pre_height=%.3f, place_offset=%.3f, retreat_height=%.3f",
                      self.pre_height, self.place_offset, self.retreat_height)

        # ========== 等 /table_centroid ==========
        rospy.loginfo("[INIT] Waiting for /table_centroid ...")
        self.table_centroid = rospy.wait_for_message("/table_centroid", PointStamped)
        rospy.loginfo("[INIT] Got table centroid: (%.3f, %.3f, %.3f) in frame [%s]",
                      self.table_centroid.point.x,
                      self.table_centroid.point.y,
                      self.table_centroid.point.z,
                      self.table_centroid.header.frame_id)

        # ========== 抬 torso ==========
        self.raise_torso()
        rospy.sleep(0.5)

        # ========== MoveIt 关节预姿态 ==========
        self.move_arm_to_joint_prepose()
        rospy.sleep(1.0)

        # ========== 锁定当前 EE 姿态 ==========
        carry_pose = self.arm.get_current_pose().pose
        self.locked_ori = carry_pose.orientation
        rospy.loginfo("[INIT] Lock EE orientation for placing: q=(%.3f, %.3f, %.3f, %.3f)",
                      self.locked_ori.x, self.locked_ori.y,
                      self.locked_ori.z, self.locked_ori.w)

        # ========== 执行放置 ==========
        self.place_bottle()
        rospy.loginfo("[END] Finished place_bottle()")

        moveit_commander.roscpp_shutdown()

    # ------------------------------------------------------------------
    # 抬 Torso：直接发关节轨迹
    # ------------------------------------------------------------------
    def raise_torso(self, target_height=0.20):
        traj = JointTrajectory()
        traj.joint_names = ["torso_lift_joint"]

        pt = JointTrajectoryPoint()
        pt.positions = [target_height]
        pt.time_from_start = rospy.Duration(2.0)
        traj.points.append(pt)

        rospy.loginfo("[TORSO] Raising torso to %.3f m ...", target_height)
        for i in range(3):
            self.torso_pub.publish(traj)
            rospy.loginfo("[TORSO] Published torso command #%d", i + 1)
            rospy.sleep(0.2)
        rospy.loginfo("[TORSO] Torso command sent (check joint_states for feedback).")

    # ------------------------------------------------------------------
    # 关节空间预姿态：完全用 MoveIt
    # ------------------------------------------------------------------
    def move_arm_to_joint_prepose(self):
        default_arm_joints = [0.40, -1.17, -1.90, 2.30, -1.30, -0.45, 0.00]
        arm_positions = rospy.get_param("~prepose_arm_positions", default_arm_joints)

        if len(arm_positions) != 7:
            rospy.logwarn("[PREPOSE] prepose_arm_positions 长度不是 7，使用默认值。")
            arm_positions = default_arm_joints

        rospy.loginfo("[PREPOSE] MoveIt joint pre-pose target:")
        rospy.loginfo("[PREPOSE]  arm joints = [%.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f]",
                      *arm_positions)

        self.arm.set_start_state_to_current_state()
        self.arm.set_max_velocity_scaling_factor(0.25)
        self.arm.set_max_acceleration_scaling_factor(0.15)
        self.arm.set_joint_value_target(arm_positions)

        plan = self.arm.plan()
        success = False
        traj = None

        if isinstance(plan, tuple):
            success_flag, traj, planning_time, error_code = plan
            success = bool(success_flag)
            rospy.loginfo(
                "[PREPOSE] plan() tuple: success=%s, planning_time=%.3f, error_code=%s",
                str(success_flag), planning_time, str(error_code)
            )
            if traj is not None:
                rospy.loginfo("[PREPOSE] Planned trajectory has %d points",
                              len(traj.joint_trajectory.points))
        else:
            traj = plan
            if traj is not None and len(traj.joint_trajectory.points) > 0:
                success = True
                rospy.loginfo("[PREPOSE] plan() returned RobotTrajectory with %d points",
                              len(traj.joint_trajectory.points))
            else:
                rospy.logwarn("[PREPOSE] plan() returned empty trajectory")

        if not success:
            rospy.logerr("[PREPOSE] Planning pre-pose failed，后续动作可能继续失败。")
            return

        rospy.loginfo("[PREPOSE] Executing pre-pose trajectory ...")
        exec_ok = self.arm.execute(traj, wait=True)
        if not exec_ok:
            rospy.logerr("[PREPOSE] Execution of pre-pose failed.")
            return

        self.arm.stop()
        self.arm.clear_pose_targets()
        cur = self.arm.get_current_pose().pose
        rospy.loginfo("[PREPOSE] Reached pre-pose: pos(%.3f, %.3f, %.3f)",
                      cur.position.x, cur.position.y, cur.position.z)

    # ------------------------------------------------------------------
    # 通用：先 plan 再 execute
    # ------------------------------------------------------------------
    def move_arm_to(self, pose):
        rospy.loginfo("[ARM] move_arm_to() called")
        rospy.loginfo("[ARM] Target pose: pos(%.3f, %.3f, %.3f), ori(q=%.3f, %.3f, %.3f, %.3f)",
                      pose.position.x, pose.position.y, pose.position.z,
                      pose.orientation.x, pose.orientation.y,
                      pose.orientation.z, pose.orientation.w)

        current = self.arm.get_current_pose().pose
        rospy.loginfo("[ARM] Current pose: pos(%.3f, %.3f, %.3f)",
                      current.position.x, current.position.y, current.position.z)

        self.arm.set_start_state_to_current_state()
        self.arm.set_pose_target(pose)
        self.arm.set_max_velocity_scaling_factor(0.20)
        self.arm.set_max_acceleration_scaling_factor(0.10)

        rospy.loginfo("[ARM] Planning to target ...")
        plan = self.arm.plan()

        success = False
        traj = None

        if isinstance(plan, tuple):
            success_flag, traj, planning_time, error_code = plan
            success = bool(success_flag)
            rospy.loginfo(
                "[ARM] plan() tuple: success=%s, planning_time=%.3f, error_code=%s",
                str(success_flag), planning_time, str(error_code)
            )
            if traj is not None:
                rospy.loginfo("[ARM] Planned trajectory has %d points",
                              len(traj.joint_trajectory.points))
        else:
            traj = plan
            if traj is not None and len(traj.joint_trajectory.points) > 0:
                success = True
                rospy.loginfo("[ARM] plan() returned RobotTrajectory with %d points",
                              len(traj.joint_trajectory.points))
            else:
                rospy.logwarn("[ARM] plan() returned empty trajectory")

        if not success:
            rospy.logerr("[ARM] Planning failed. Cannot reach target pose.")
            return False

        rospy.loginfo("[ARM] Executing trajectory ...")
        exec_ok = self.arm.execute(traj, wait=True)
        if not exec_ok:
            rospy.logerr("[ARM] Execution failed.")
            return False

        self.arm.stop()
        self.arm.clear_pose_targets()

        new_pose = self.arm.get_current_pose().pose
        rospy.loginfo("[ARM] Reached pose: pos(%.3f, %.3f, %.3f)",
                      new_pose.position.x, new_pose.position.y, new_pose.position.z)
        return True

        # ------------------------------------------------------------------
    # 笛卡尔直线运动：仿照 grasp 里的 moveEndEffectorStraightDirection
    # ------------------------------------------------------------------
    def move_cartesian_to(self, target_pose):
        start_pose = self.arm.get_current_pose().pose
        rospy.loginfo("[CART] Cartesian move from pos(%.3f, %.3f, %.3f) to pos(%.3f, %.3f, %.3f)",
                      start_pose.position.x, start_pose.position.y, start_pose.position.z,
                      target_pose.position.x, target_pose.position.y, target_pose.position.z)

        waypoints = []
        waypoints.append(start_pose)
        waypoints.append(target_pose)

        # 注意：你当前环境的 compute_cartesian_path 签名是
        #   compute_cartesian_path(list, double, bool)
        # 所以第三个参数必须是 bool（通常用作 avoid_collisions）
        (traj, fraction) = self.arm.compute_cartesian_path(
            waypoints,   # waypoints
            0.005,       # eef_step
            True         # avoid_collisions
        )

        rospy.loginfo("[CART] Path fraction: %.2f", fraction)
        if fraction < 0.99:
            rospy.logerr("[CART] Cartesian path planning failed.")
            return False

        rospy.loginfo("[CART] Executing Cartesian trajectory ...")
        exec_ok = self.arm.execute(traj, wait=True)
        if not exec_ok:
            rospy.logerr("[CART] Cartesian execution failed.")
            return False

        self.arm.stop()
        self.arm.clear_pose_targets()

        cur = self.arm.get_current_pose().pose
        rospy.loginfo("[CART] Cartesian done. Current pose: pos(%.3f, %.3f, %.3f)",
                      cur.position.x, cur.position.y, cur.position.z)
        return True


    # ------------------------------------------------------------------
    # 打开夹爪
    # ------------------------------------------------------------------
    def open_gripper(self):
        traj = JointTrajectory()
        traj.joint_names = [
            "gripper_left_finger_joint",
            "gripper_right_finger_joint"
        ]

        pt = JointTrajectoryPoint()
        pt.positions = [0.04, 0.04]
        pt.time_from_start = rospy.Duration(1.5)
        traj.points.append(pt)

        rospy.loginfo("[GRIPPER] Opening gripper ...")
        for i in range(3):
            self.gripper_pub.publish(traj)
            rospy.loginfo("[GRIPPER] Publish open command #%d", i + 1)
            rospy.sleep(0.1)

    # ------------------------------------------------------------------
    # 主流程：锁当前姿态，只移动位置
    # ------------------------------------------------------------------
    def place_bottle(self):
        cx = self.table_centroid.point.x
        cy = self.table_centroid.point.y
        cz = self.table_centroid.point.z

        ori = self.locked_ori

        rospy.loginfo("[PLACE] Using locked orientation: q=(%.3f, %.3f, %.3f, %.3f)",
                      ori.x, ori.y, ori.z, ori.w)
        rospy.loginfo("[PLACE] Start placing procedure")
        rospy.loginfo("[PLACE] Table centroid: (%.3f, %.3f, %.3f)", cx, cy, cz)

        pre_pose = Pose()
        pre_pose.position.x = cx
        pre_pose.position.y = cy
        pre_pose.position.z = cz + self.pre_height
        pre_pose.orientation = ori

        place_pose = Pose()
        place_pose.position.x = cx
        place_pose.position.y = cy
        place_pose.position.z = cz + self.place_offset
        place_pose.orientation = ori

        retreat_pose = Pose()
        retreat_pose.position.x = cx
        retreat_pose.position.y = cy
        retreat_pose.position.z = cz + self.retreat_height
        retreat_pose.orientation = ori

        rospy.loginfo("[PLACE] Pre-place pose:    pos(%.3f, %.3f, %.3f)",
                      pre_pose.position.x, pre_pose.position.y, pre_pose.position.z)
        rospy.loginfo("[PLACE] Place pose:        pos(%.3f, %.3f, %.3f)",
                      place_pose.position.x, place_pose.position.y, place_pose.position.z)
        rospy.loginfo("[PLACE] Retreat pose:      pos(%.3f, %.3f, %.3f)",
                      retreat_pose.position.x, retreat_pose.position.y, retreat_pose.position.z)

        # 1) 先到 pre-place（全局规划）
        rospy.loginfo("[PLACE] Moving to pre-place pose ...")
        if not self.move_arm_to(pre_pose):
            rospy.logerr("[PLACE] Failed to reach pre-place pose (planning or execution error).")
            return
        rospy.loginfo("[PLACE] Reached pre-place pose.")
        rospy.sleep(0.5)

        # 2) pre-place -> place：用笛卡尔直线
        rospy.loginfo("[PLACE] Moving down to place pose (Cartesian) ...")
        if not self.move_cartesian_to(place_pose):
            rospy.logerr("[PLACE] Failed to reach place pose (Cartesian).")
            return
        rospy.loginfo("[PLACE] Reached place pose.")
        rospy.sleep(0.5)

        # 3) 打开夹爪
        self.open_gripper()
        rospy.sleep(0.5)

        # 4) place -> retreat：再用笛卡尔直线往上
        rospy.loginfo("[PLACE] Retreating to retreat pose (Cartesian) ...")
        if not self.move_cartesian_to(retreat_pose):
            rospy.logerr("[PLACE] Failed to reach retreat pose (Cartesian).")
            return
        rospy.loginfo("[PLACE] Retreat pose reached. Placing done.")


if __name__ == "__main__":
    try:
        BottlePlacer()
    except rospy.ROSInterruptException:
        pass

