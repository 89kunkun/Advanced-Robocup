#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import math
import moveit_commander
import geometry_msgs.msg
import trajectory_msgs.msg
from geometry_msgs.msg import PointStamped, PoseStamped


class BottlePlacer:
    def __init__(self):
        rospy.init_node("place_bottle_on_table")
        rospy.loginfo("[INIT] place_bottle_on_table node started")

        # ---------- MoveIt 初始化 ----------
        moveit_commander.roscpp_initialize([])
        self.arm = moveit_commander.MoveGroupCommander("arm")
        self.scene = moveit_commander.PlanningSceneInterface()

        self.arm.set_pose_reference_frame("base_footprint")
        self.arm.set_end_effector_link("gripper_link")
        self.arm.set_goal_tolerance(0.02)
        self.arm.set_max_velocity_scaling_factor(0.25)
        self.arm.set_max_acceleration_scaling_factor(0.15)
        self.arm.set_planning_time(10.0)

        rospy.loginfo("[INIT] MoveGroup 'arm' ready. Ref frame: %s, EE: %s",
                      self.arm.get_planning_frame(),
                      self.arm.get_end_effector_link())

        # ---------- gripper ----------
        self.gripper_pub = rospy.Publisher(
            "/gripper_controller/command",
            trajectory_msgs.msg.JointTrajectory,
            queue_size=1
        )

        # ---------- 放置动作高度参数（可调整） ----------
        # pre_height:    预放置位置离桌面高度
        # place_offset:  真正放瓶子时离桌面的高度（可以稍微 > 瓶底高度，避免撞桌面）
        # retreat_height:放完后，末端在桌面上方的高度
        self.pre_height     = rospy.get_param("~pre_height",     0.15)
        self.place_offset   = rospy.get_param("~place_offset",   0.10)
        self.retreat_height = rospy.get_param("~retreat_height", 0.20)

        rospy.loginfo("[PARAM] pre_height=%.3f  place_offset=%.3f  retreat_height=%.3f",
                      self.pre_height, self.place_offset, self.retreat_height)

        # ---------- 桌子尺寸（可调整） ----------
        # 这些参数就是桌子的碰撞盒大小，你可以根据 Gazebo 中的桌子调整：
        # 例如桌子长 1.0m、宽 0.2m、厚 0.4m：
        self.table_size_x = rospy.get_param("~table_size_x", 1.0)
        self.table_size_y = rospy.get_param("~table_size_y", 0.20)
        self.table_size_z = rospy.get_param("~table_size_z", 0.40)

        rospy.loginfo("[PARAM] Table size = (x=%.3f  y=%.3f  z=%.3f)",
                      self.table_size_x, self.table_size_y, self.table_size_z)

        # ---------- 读取桌子中心点 ----------
        rospy.loginfo("[INIT] Waiting for /table_centroid ...")
        self.table_centroid = rospy.wait_for_message("/table_centroid", PointStamped)
        rospy.loginfo("[INIT] Got table centroid: (%.3f, %.3f, %.3f) [%s]",
                      self.table_centroid.point.x,
                      self.table_centroid.point.y,
                      self.table_centroid.point.z,
                      self.table_centroid.header.frame_id)

        # ---------- 添加桌子碰撞体 ----------
        self.add_table_collision()

        rospy.sleep(0.5)
        self.place_bottle()
        rospy.loginfo("[END] Finished place_bottle()")
        moveit_commander.roscpp_shutdown()

    # =====================================================================
    #  添加桌子碰撞体：根据桌面中心点 + 参数化尺寸
    # =====================================================================
    def add_table_collision(self):
        cx = self.table_centroid.point.x
        cy = self.table_centroid.point.y
        cz = self.table_centroid.point.z  # 桌面的上表面高度

        size_x = self.table_size_x
        size_y = self.table_size_y
        size_z = self.table_size_z

        # 计算碰撞盒中心 z：
        # 桌面上表面在 cz，桌子的厚度为 size_z，
        # 那么桌子中心 z = cz - size_z/2，再稍微往下偏一点（+0.02）避免和桌面表面数值重合。
        center_z = cz - (size_z / 2.0) + 0.02

        pose = PoseStamped()
        pose.header.frame_id = "base_footprint"
        pose.pose.position.x = cx
        pose.pose.position.y = cy
        pose.pose.position.z = center_z
        pose.pose.orientation.w = 1.0

        rospy.loginfo("[SCENE] Adding table collision: center(%.3f, %.3f, %.3f) size(%.3f, %.3f, %.3f)",
                      pose.pose.position.x, pose.pose.position.y, pose.pose.position.z,
                      size_x, size_y, size_z)

        # Python 版 MoveIt：使用 add_box 来添加碰撞物体
        self.scene.add_box("table", pose, (size_x, size_y, size_z))
        rospy.sleep(1.0)  # 给规划场景一点时间更新

    # =====================================================================
    #  单次规划 + 执行（带调试信息）
    # =====================================================================
    def move_arm_to(self, pose):
        rospy.loginfo("[ARM] Target pose: pos(%.3f, %.3f, %.3f)",
                      pose.position.x, pose.position.y, pose.position.z)

        self.arm.set_start_state_to_current_state()
        self.arm.set_pose_target(pose)

        plan = self.arm.plan()

        # 兼容 noetic 里 plan() 返回 tuple 或 RobotTrajectory 两种情况
        if isinstance(plan, tuple):
            success = bool(plan[0])
            traj = plan[1]
        else:
            traj = plan
            success = traj and len(traj.joint_trajectory.points) > 0

        if not success:
            rospy.logerr("[ARM] Planning failed.")
            return False

        exec_ok = self.arm.execute(traj, wait=True)
        if not exec_ok:
            rospy.logerr("[ARM] Execution failed.")
            return False

        self.arm.stop()
        self.arm.clear_pose_targets()
        return True

    # =====================================================================
    #  打开 gripper
    # =====================================================================
    def open_gripper(self):
        traj = trajectory_msgs.msg.JointTrajectory()
        traj.joint_names = ["gripper_left_finger_joint", "gripper_right_finger_joint"]
        pt = trajectory_msgs.msg.JointTrajectoryPoint()
        pt.positions = [0.04, 0.04]  # 张开一点
        pt.time_from_start = rospy.Duration(1.0)
        traj.points.append(pt)

        rospy.loginfo("[GRIPPER] Opening gripper ...")
        for i in range(3):
            self.gripper_pub.publish(traj)
            rospy.loginfo("[GRIPPER] Publish open command #%d", i + 1)
            rospy.sleep(0.1)

    # =====================================================================
    #  主流程：放瓶子
    # =====================================================================
    def place_bottle(self):
        cx = self.table_centroid.point.x
        cy = self.table_centroid.point.y
        cz = self.table_centroid.point.z

        # 用当前末端姿态作为固定姿态（和 grasp 后保持一致）
        current_pose = self.arm.get_current_pose().pose
        ori = current_pose.orientation

        # 1) Pre-place：桌面上方 pre_height
        pre = geometry_msgs.msg.Pose()
        pre.position.x = cx
        pre.position.y = cy
        pre.position.z = cz + self.pre_height
        pre.orientation = ori

        # 2) Place：放瓶子时的位置（稍微高于桌面）
        place = geometry_msgs.msg.Pose()
        place.position.x = cx
        place.position.y = cy
        place.position.z = cz + self.place_offset
        place.orientation = ori

        # 3) Retreat：放完后抬高一点
        retreat = geometry_msgs.msg.Pose()
        retreat.position.x = cx
        retreat.position.y = cy
        retreat.position.z = cz + self.retreat_height
        retreat.orientation = ori

        rospy.loginfo("[PLACE] Start placing procedure")
        rospy.loginfo("[PLACE] Table centroid: (%.3f, %.3f, %.3f)", cx, cy, cz)
        rospy.loginfo("[PLACE] Pre-place pose:    pos(%.3f, %.3f, %.3f)",
                      pre.position.x, pre.position.y, pre.position.z)
        rospy.loginfo("[PLACE] Place pose:        pos(%.3f, %.3f, %.3f)",
                      place.position.x, place.position.y, place.position.z)
        rospy.loginfo("[PLACE] Retreat pose:      pos(%.3f, %.3f, %.3f)",
                      retreat.position.x, retreat.position.y, retreat.position.z)

        # ----------- 2) Move to pre-place -----------
        rospy.loginfo("[PLACE] Moving to pre-place pose ...")
        if not self.move_arm_to(pre):
            rospy.logerr("[PLACE] Failed to reach pre-place pose.")
            return
        rospy.loginfo("[PLACE] Reached pre-place pose.")
        rospy.sleep(0.5)

        # ----------- 3) Move to place pose -----------
        rospy.loginfo("[PLACE] Moving down to place pose ...")
        if not self.move_arm_to(place):
            rospy.logerr("[PLACE] Failed to reach place pose.")
            return
        rospy.loginfo("[PLACE] Reached place pose.")
        rospy.sleep(0.5)

        # ----------- 4) Open gripper -----------
        self.open_gripper()
        rospy.sleep(0.5)

        # ----------- 5) Retreat -----------
        rospy.loginfo("[PLACE] Retreating to retreat pose ...")
        if not self.move_arm_to(retreat):
            rospy.logerr("[PLACE] Failed to reach retreat pose.")
            return
        rospy.loginfo("[PLACE] Retreat pose reached. Placing done.")


if __name__ == "__main__":
    try:
        BottlePlacer()
    except rospy.ROSInterruptException:
        pass

