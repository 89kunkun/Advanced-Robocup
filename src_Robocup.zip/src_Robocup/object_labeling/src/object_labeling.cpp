#include <object_labeling/object_labeling.h>
#include <yolo_v8_detector/BoundingBoxes.h>
#include <yolo_v8_detector/BoundingBox.h>


ObjectLabeling::ObjectLabeling(
    const std::string& objects_cloud_topic_, 
    const std::string& camera_info_topic,
    const std::string& camera_frame) :
  is_cloud_updated_(false),
  has_camera_info_(false),
  objects_cloud_topic_(objects_cloud_topic_),
  camera_info_topic_(camera_info_topic),
  camera_frame_(camera_frame),
  K_(Eigen::Matrix3d::Zero())
{
}

ObjectLabeling::~ObjectLabeling()
{
}

bool ObjectLabeling::initalize(ros::NodeHandle& nh)
{
  // Subscribe to objects pointcloud published by the plane_segmentation_node
  object_point_cloud_sub_ = nh.subscribe(objects_cloud_topic_, 10, &ObjectLabeling::cloudCallback, this);
  // Subscribe to bounding boxes from yolo (object_labeling_node)
  object_detections_sub_ = nh.subscribe("/yolo_v8_detector/bounding_boxes", 10, &ObjectLabeling::detectionCallback, this);
  // Subscribe to camera info from robot to obtain the camera matrix K
  camera_info_sub_ = nh.subscribe(camera_info_topic_, 10, &ObjectLabeling::cameraInfoCallback, this);

  // Publish the labled objects as PointCloudl type (see typedefs in header)
  labeled_object_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>("/labeled_object_point_cloud", 1);

  // Publish the LABELED object names as visulaization marker (http://wiki.ros.org/rviz/DisplayTypes/Marker)
  text_marker_pub_ = nh.advertise<visualization_msgs::MarkerArray>("/text_markers", 1);

  centroid_pub_ = nh.advertise<geometry_msgs::PointStamped>("cluster_centroid", 1);
  
  // NEW：发布 6D 物体位姿
  pose_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/object_pose", 10);
  axis_pub_ = nh.advertise<visualization_msgs::MarkerArray>("/object_axes", 10);

  // init internal pointclouds for processing (again pcl uses pointers)
  object_point_cloud_.reset(new PointCloud);    // holds unlabled object point cloud
  labeled_point_cloud_.reset(new PointCloudl);  // holds labled object point cloud

  // Setup a mapping from class names the ones given by yolo (see yolo bounding_boxes message for classes)
  //#>>>>Note: We will use 0 as 'unkown' type
  dict_["bottle"] = 1;
  dict_["cup"] = 2;
  dict_["person"] = 5;

  return true;
}

void ObjectLabeling::update(const ros::Time& time)
{
  // camera info and point cloud available
  if(is_cloud_updated_ && has_camera_info_)
  {
    is_cloud_updated_ = false;

    // label the objects in pointcloud based on 2d bounding boxes 
    if(!labelObjects(object_point_cloud_, labeled_point_cloud_))
    {
      ROS_WARN("Object labeling failed.");
      return;
    }
    
    // Publish labeled_point_cloud_ to ros
    sensor_msgs::PointCloud2 labeled_point_cloud_msg;
    pcl::toROSMsg(*labeled_point_cloud_, labeled_point_cloud_msg);
    labeled_point_cloud_msg.header.frame_id = object_point_cloud_->header.frame_id;
    labeled_point_cloud_msg.header.stamp = time;
    labeled_object_cloud_pub_.publish(labeled_point_cloud_msg);

    // Publish text_markers_ to ros
    for (auto& marker : text_markers_.markers) {
      marker.header.frame_id = object_point_cloud_->header.frame_id;
      marker.header.stamp = time;
    }
    text_marker_pub_.publish(text_markers_);

  }
}

bool ObjectLabeling::labelObjects(CloudPtr& input, CloudPtrl& output)
{
  //#>>>>GOAL: Split input pointcloud into seperate blobs, compute centroid,
  //#>>>>GOAL: project centorid into the camera image and match with bounding box
  //#>>>>GOAL: finally label the pointcloud with object type

// 1. Euclidean clustering
  // First we need to cluster the input cloud into seperated clusters,
  // each of them represents an object on the table.

  //#>>>>TODO: Use EuclideanClusterExtraction to seperate the pointcloud into clusters
  //#>>>>Hint: https://pcl.readthedocs.io/projects/tutorials/en/master/cluster_extraction.html?highlight=EuclideanClusterExtraction

  if (!input || input->empty()) {
    ROS_WARN("Input cloud is null or empty!");
    return false;
  }

  pcl::search::KdTree<PointT>::Ptr tree(new pcl::search::KdTree<PointT>);
  tree->setInputCloud(input);
  
  // holds the extracted cluster indices (just a integer for identifiction)
  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<PointT> ec;
  ec.setClusterTolerance(0.05);
  ec.setMinClusterSize(50);
  ec.setMaxClusterSize(25000);
  ec.setSearchMethod(tree);
  ec.setInputCloud(input);
  ec.extract(cluster_indices);

  if (cluster_indices.empty()) {
    ROS_WARN("Euclidean clustering found no clusters!");
    return false;
  }

  const std::string base_frame = "base_footprint";
  const std::string cloud_frame = input->header.frame_id;

  // TF: base_footprint <- cloud_frame
  tf::StampedTransform cloud_to_base_tf;
  tfListener_.lookupTransform(base_frame, cloud_frame, ros::Time(0), cloud_to_base_tf);
  Eigen::Affine3d T_base_cloud;
  tf::transformTFToEigen(cloud_to_base_tf, T_base_cloud);

  // TF: base_footprint <- camera_frame (用于后续投影)
  tf::StampedTransform camera_to_base_tf;
  tfListener_.lookupTransform(base_frame, camera_frame_, ros::Time(0), camera_to_base_tf);
  Eigen::Affine3d T_base_camera;
  tf::transformTFToEigen(camera_to_base_tf, T_base_camera);

// 2. Calculate the centroid of each cluster
  //#>>>>TODO: Iterate over each cluster and compute its centroid point (= mean)
  //#>>>>TODO: Push the centroid into the vector of centroids
  std::vector<Eigen::Vector3d> centroids;
  text_markers_.markers.clear();
  size_t cluster_id = 0;

  for (const auto& indices : cluster_indices)
  {
    pcl::PointCloud<PointT>::Ptr cloud_cluster(new pcl::PointCloud<PointT>);
    for (const auto& idx : indices.indices)
        cloud_cluster->push_back(input->points[idx]);

    //-----------------------------------------------------
    // 1. 计算 3D 质心（摄像头坐标系）
    //-----------------------------------------------------
    Eigen::Vector4d centroid_cam;
    pcl::compute3DCentroid(*cloud_cluster, centroid_cam);

    //-----------------------------------------------------
    // 3. 将质心转换到 base_footprint 坐标
    //-----------------------------------------------------
    Eigen::Vector3d centroid_base = T_base_cloud * centroid_cam.head<3>();

    centroids.push_back(centroid_base);

    //-----------------------------------------------------
    // 4. PCA 主方向（在摄像头坐标系）
    //-----------------------------------------------------
    Eigen::Matrix3f cov;
    pcl::computeCovarianceMatrixNormalized(
        *cloud_cluster, 
        centroid_cam.cast<float>(),
        cov
    );

    Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> solver(cov);

    // PCA 三轴
    Eigen::Vector3d major_axis  = solver.eigenvectors().col(2).cast<double>().normalized();
    Eigen::Vector3d middle_axis = solver.eigenvectors().col(1).cast<double>().normalized();
    Eigen::Vector3d minor_axis  = solver.eigenvectors().col(0).cast<double>().normalized();

    // R_cam: 摄像头坐标系下的物体旋转
    Eigen::Matrix3d R_cam;
    R_cam.col(0) = major_axis;
    R_cam.col(1) = middle_axis;
    R_cam.col(2) = minor_axis;

    // Eigen::Matrix3d R_cam = R_cam_float.cast<double>();

    static bool first_frame = true;
    static Eigen::Vector3d prev_x, prev_y, prev_z;

    Eigen::Matrix3d R_base_raw = T_base_cloud.rotation() * R_cam;

    Eigen::Vector3d x_axis = R_base_raw.col(0).normalized();
    Eigen::Vector3d y_axis = R_base_raw.col(1).normalized();
    Eigen::Vector3d z_axis = R_base_raw.col(2).normalized();

    if (!first_frame)
    {
      if(prev_x.dot(x_axis) < 0) x_axis = -x_axis;
      if(prev_y.dot(y_axis) < 0) y_axis = -y_axis;
      if(prev_z.dot(z_axis) < 0) z_axis = -z_axis;
    }

    // 重新正交化，防止数值误差导致四元数非单位
    x_axis.normalize();
    // 去除 y 在 x 上的投影后归一化
    y_axis = (y_axis - x_axis * x_axis.dot(y_axis)).normalized();
    // 重建正交 z
    z_axis = x_axis.cross(y_axis).normalized();

    prev_x = x_axis;
    prev_y = y_axis;
    prev_z = z_axis;
    first_frame = false;

    Eigen::Matrix3d R_base;
    R_base.col(0) = x_axis;
    R_base.col(1) = y_axis;
    R_base.col(2) = z_axis;

    Eigen::Quaterniond q_base(R_base);
    q_base.normalize();

    //-----------------------------------------------------
    // 6. 发布物体 6D 位姿（base_footprint）
    //-----------------------------------------------------
    geometry_msgs::PoseStamped pose_msg;
    pose_msg.header.frame_id = "base_footprint";
    pose_msg.header.stamp = ros::Time::now();

    pose_msg.pose.position.x = centroid_base.x();
    pose_msg.pose.position.y = centroid_base.y();
    pose_msg.pose.position.z = centroid_base.z();

    pose_msg.pose.orientation.x = q_base.x();
    pose_msg.pose.orientation.y = q_base.y();
    pose_msg.pose.orientation.z = q_base.z();
    pose_msg.pose.orientation.w = q_base.w();

    pose_pub_.publish(pose_msg);

    //-----------------------------------------------------
    // 7. 发布 cluster 质心（base_footprint）
    //-----------------------------------------------------
    geometry_msgs::PointStamped centroid_msg;
    centroid_msg.header.frame_id = "base_footprint";
    centroid_msg.header.stamp = ros::Time::now();
    centroid_msg.point.x = centroid_base.x();
    centroid_msg.point.y = centroid_base.y();
    centroid_msg.point.z = centroid_base.z();

    centroid_pub_.publish(centroid_msg);

    cluster_id++;

    //-----------------------------------------------------
    // 8. 为当前物体绘制 3D 坐标轴并发布到 RViz
    //-----------------------------------------------------
    visualization_msgs::MarkerArray axis_markers;
    axis_markers.markers.clear();

    auto make_arrow = [&](int id, const Eigen::Vector3d &start,
                          const Eigen::Vector3d &direction,
                          const std_msgs::ColorRGBA &color,
                          const std::string &ns)
    {
      visualization_msgs::Marker m;
      m.header.frame_id = "base_footprint";
      m.header.stamp = ros::Time::now();
      m.ns = ns;
      m.id = id;
      m.type = visualization_msgs::Marker::ARROW;
      m.action = visualization_msgs::Marker::ADD;
      m.scale.x = 0.02; // shaft diameter
      m.scale.y = 0.04; // head diameter
      m.scale.z = 0.06;  // head length

      geometry_msgs::Point p_start, p_end;
      p_start.x = start.x();
      p_start.y = start.y();
      p_start.z = start.z();

      Eigen::Vector3d end = start + direction * 0.15; // arrow length 15cm
      p_end.x = end.x();
      p_end.y = end.y();
      p_end.z = end.z();  

      m.points.push_back(p_start);
      m.points.push_back(p_end);
      m.color = color;

      return m;
    };

    // RGB Colors
    std_msgs::ColorRGBA col_x; col_x.r = 1.0; col_x.a = 1.0;
    std_msgs::ColorRGBA col_y; col_y.g = 1.0; col_y.a = 1.0;
    std_msgs::ColorRGBA col_z; col_z.b = 1.0; col_z.a = 1.0;

    // // rotation axis in base_footprint
    // Eigen::Vector3d x_axis_vis = x_axis;
    // Eigen::Vector3d y_axis_vis = y_axis;
    // Eigen::Vector3d z_axis_vis = z_axis;

    // create arrows
    axis_markers.markers.push_back(make_arrow(cluster_id * 10 + 1, centroid_base, x_axis, col_x, "axis_x"));
    axis_markers.markers.push_back(make_arrow(cluster_id * 10 + 2, centroid_base, y_axis, col_y, "axis_y"));
    axis_markers.markers.push_back(make_arrow(cluster_id * 10 + 3, centroid_base, z_axis, col_z, "axis_z"));

    // publish
    axis_pub_.publish(axis_markers);

    //-----------------------------------------------------
    //在 TERMINAL 打印质心与姿态
    //-----------------------------------------------------
    ROS_INFO_STREAM("\n[ObjectLabeling] Cluster " << cluster_id
        << "\n  Centroid (base_footprint): "
        << "X=" << centroid_base.x()
        << "  Y=" << centroid_base.y()
        << "  Z=" << centroid_base.z()
        << "\n  Orientation (Quaternion): "
        << "qx=" << q_base.x()
        << "  qy=" << q_base.y()
        << "  qz=" << q_base.z()
        << "  qw=" << q_base.w());
  }

  // Next we need to find the pixel coordinates of the centroids within the 2d
  // camera image. This projection is handled by the camera matrix
  // First, the centorids need to be transformed from the pointcloud frame into the
  // camera frame.

// 3. TF: base_link -> camera_frame
  //#>>>>TODO: Get the homogenous transformation matrix of the base frame with respect
  //#>>>>TODO: to the camera frame.
  //#>>>>Hint: look up the transformation through the tf tree: tfListener_.lookupTransform(...)
  //#>>>>TODO: Convert the tf::StampedTransform into an Eigen::Affine3d
  //#>>>>Hint: tf::transformTFToEigen(...) can do the job

  // 这里使用前面获取的 T_base_camera

// 4. Transform the centroids to the camera coordinate frame
  //#>>>>TODO: Transform the centorids into the camera frame by multiplying them 
  //#>>>>TODO: with the transformation that takes a point in the pointcloud frame and turns it
  //#>>>>TODO: into a point in the camera frame. Do this for all centroids.

  std::vector<Eigen::Vector3d> centroids_camera;
  Eigen::Affine3d T_camera_base = T_base_camera.inverse();
  for (const auto& c : centroids)
    centroids_camera.push_back(T_camera_base * c);

// 5. Camera projection: 3D -> 2D
  //#>>>>TODO: Project the transformed centorids into the camera plane by using the camera matrix K
  //#>>>>Hint: Multiplying a 3d vector with the 3x3 camera matrix gives a vector in R^3
  //#>>>>Hint: To get pixel coordinates in R^2 you need to convert them to homogenous 2d coordinates
  //#>>>>Hint: ( = divide by the last component and drop the one in third component.)
  std::vector<Eigen::Vector2d> pixel_centroids;
  for (const auto& c : centroids_camera)
  {
    Eigen::Vector3d homegenous_uvw = K_ * c;
    homegenous_uvw /= homegenous_uvw[2];
    pixel_centroids.emplace_back(homegenous_uvw[0], homegenous_uvw[1]);
  }

  // Now the centorids of each cluster are given as pixel coordinates in the 2d image
  // plane of the camera. What remains is to find the bounding box that matches to each of 
  // those controids.

// 6. Assign each detection box to the nearest centroid
  //#>>>>TODO: Find the best match between pixel_centroids and detections_
  //#>>>>Hint: Use the euclidian distance between the pixel_centroids and the boundingbox centers
  //#>>>>Hint: For each bounding box find the closest cenroid 
  //#>>>>TODO: If a cluster cant be matched (no bounding boxes left) assign 0 as label

  std::vector<int> assigned_labels(cluster_indices.size(), 0);                  // lables of each centroid
  std::vector<std::string> assigned_classes(cluster_indices.size(), "unknown"); // class names of each centroid

  for(size_t i = 0; i < detections_.size(); ++i)
  {
    // get the bounding box we want to find the closest cenroid 
    const darknet_ros_msgs::BoundingBox& bounding_box = detections_[i];

    //#>>>>TODO: For all cenroids compute the distance to the boudning box
    //#>>>>TODO: select the clostes as match and get its index in pixel_centroids
    int match; // = ?
    double closest_distance = std::numeric_limits<double>::max();
    Eigen::Vector2d bounding_box_centroid{
      (bounding_box.xmax + bounding_box.xmin)/2.0,
      (bounding_box.ymax + bounding_box.ymin)/2.0
    };
    for (size_t j = 0; j < pixel_centroids.size(); j++)
    {
      double distance = (pixel_centroids[j] - bounding_box_centroid).norm();
      if (distance < closest_distance)
      {
        closest_distance = distance;
        match = j;
      }
    }

    // remember the label of match
    if(dict_.find(bounding_box.Class) != dict_.end())
    {
      assigned_labels[match] = dict_[bounding_box.Class]; // set match to defined class index
      assigned_classes[match] = bounding_box.Class;       // set match to class name
    }
  }

// 7. Reconstruct and build the labeled point cloud
  // relabel the point cloud
  output->points.clear();
  output->header = input->header;

  PointTl pt;
  size_t i = 0;
  auto cit = cluster_indices.begin();
  for(; cit != cluster_indices.end(); ++cit, ++i ) 
  {
    // relabel all the points inside cluster
    std::vector<int>::const_iterator it = cit->indices.begin();
    for(; it != cit->indices.end(); ++it ) 
    {
      PointT& cpt = input->points[*it];
      pt.x = cpt.x;
      pt.y = cpt.y;
      pt.z = cpt.z;
      pt.label = assigned_labels[i];    // Note: To test clustering without the matching stuff just use pt.lable = i
      output->points.push_back( pt );
    }
  }

// 8. Generate text annotation markers
  // create a text marker that displays the assigned class name (assigned_classes) 
  // at the 3d position of the corresponding centroid
  text_markers_.markers.resize(assigned_classes.size());
  for(size_t i = 0; i < assigned_classes.size(); ++i)
  {
    visualization_msgs::Marker marker;
    marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
    marker.text = assigned_classes[i];
    marker.pose.position.x = centroids[i].x();
    marker.pose.position.y = centroids[i].y();
    marker.pose.position.z = centroids[i].z() + 0.1;
    marker.color.a = 1.0;
    marker.scale.z = 0.1;
    marker.id = i;
    marker.header.frame_id = input->header.frame_id;
    marker.header.stamp = ros::Time::now();
    text_markers_.markers[i] = marker;
  }

  return true;
}


void ObjectLabeling::cloudCallback(const sensor_msgs::PointCloud2ConstPtr &msg)
{
  // convert to pcl
  is_cloud_updated_ = true;
  //#>>>>TODO: convert to pcl and store in object_point_cloud_
  //#>>>>Hint: pcl::fromROSMsg()
  pcl::fromROSMsg(*msg, *object_point_cloud_);
}

void ObjectLabeling::detectionCallback(const darknet_ros_msgs::BoundingBoxesConstPtr &msg)
{
  //#>>>>TODO: copy the YOLO bounding boxes
  detections_ = msg->bounding_boxes;

  // Debug
  // for (const auto& box : detections_) {
  //   ROS_INFO_STREAM("Detected class: " << box.Class);
  // }
}

void ObjectLabeling::cameraInfoCallback(const sensor_msgs::CameraInfoConstPtr &msg)
{
  // copy camera info
  has_camera_info_ = true;
  Eigen::Matrix3d K = Eigen::Matrix3d::Zero();

  //#>>>>TODO: copy the 3x3 camera matrix to K_
  //#>>>>Hint: http://docs.ros.org/en/melodic/api/sensor_msgs/html/msg/CameraInfo.html
  for(size_t i = 0; i < 9; ++i)
  {
    K(i) = msg->K[i];
  }
  K_ = K.transpose();

  // K_ << msg->K[0], msg->K[1], msg->K[2],
  //     msg->K[3], msg->K[4], msg->K[5],
  //     msg->K[6], msg->K[7], msg->K[8];
}
