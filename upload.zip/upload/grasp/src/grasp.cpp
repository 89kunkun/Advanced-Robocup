#include <grasp/grasp.h>

#include <pcl_conversions/pcl_conversions.h>

#include <moveit_msgs/RobotTrajectory.h>
#include <Eigen/Dense>
#include <tf/transform_datatypes.h>

// =======================
//    构造函数
// =======================
Grasper::Grasper(ros::NodeHandle& nh)
    : move_group_("arm")  // 如果你用的是 arm_torso，这里改成 "arm_torso"
{
    gripper_pub_ = nh.advertise<trajectory_msgs::JointTrajectory>(
        "/gripper_controller/command", 1);

    // RViz 中可视化 PCA 轴 / 物体坐标系
    axis_marker_pub_ = nh.advertise<visualization_msgs::MarkerArray>(
        "/object_axes_markers", 1);

    move_group_.setPoseReferenceFrame("base_link");
    move_group_.setEndEffectorLink("gripper_link");
    move_group_.setGoalTolerance(0.03);
    move_group_.setMaxVelocityScalingFactor(0.3);
    move_group_.setPlanningTime(15.0);
    move_group_.setStartStateToCurrentState();
    move_group_.setPlannerId("RRTConnectkConfigDefault");

    // 加载参数
    nh.param("target_label", target_label_, 1);

    nh.param("x_offset", x_offset_, 0.0);
    nh.param("y_offset", y_offset_, 0.0);
    nh.param("z_offset", z_offset_, 0.1); // default 10cm

    nh.param("grasp_roll",  grasp_rpy_[0], -M_PI/2);
    nh.param("grasp_pitch", grasp_rpy_[1], 0.0);
    nh.param("grasp_yaw",   grasp_rpy_[2], -M_PI/2);

    nh.param("pregrasp_offset_x", pregrasp_offset_x, 0.0);
    nh.param("pregrasp_offset_y", pregrasp_offset_y, 0.0);
    nh.param("pregrasp_offset_z", pregrasp_offset_z, 0.0);
}

// =======================
//   点云回调（物体）
// =======================
void Grasper::pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg)
{
    if (!got_cloud_)
    {
        cached_cloud_ = msg;
        got_cloud_ = true;
        grasp(cached_cloud_, target_label_);
    }
}

// =======================
//   点云回调（桌面）
// =======================
void Grasper::tableCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg)
{
    // 1. Point cloud conversion
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromROSMsg(*msg, *cloud);
    if (cloud->empty()) return;

    // 2. Fitting plane
    pcl::SACSegmentation<pcl::PointXYZ> seg;
    seg.setOptimizeCoefficients(true);
    seg.setModelType(pcl::SACMODEL_PLANE);
    seg.setMethodType(pcl::SAC_RANSAC);
    seg.setDistanceThreshold(0.015);
    seg.setInputCloud(cloud);
    pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
    pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
    seg.segment(*inliers, *coefficients);
    if (inliers->indices.empty()) return;

    pcl::ExtractIndices<pcl::PointXYZ> extract;
    extract.setInputCloud(cloud);
    extract.setIndices(inliers);
    pcl::PointCloud<pcl::PointXYZ>::Ptr table_inlier_cloud(
        new pcl::PointCloud<pcl::PointXYZ>);
    extract.filter(*table_inlier_cloud);

    // 3. Calculate desktop bounding box
    pcl::PointXYZ min_pt, max_pt;
    pcl::getMinMax3D(*table_inlier_cloud, min_pt, max_pt);

    double box_x = max_pt.x - min_pt.x;
    double box_y = max_pt.y - min_pt.y;
    double box_z = 0.4;
    double center_x = (min_pt.x + max_pt.x) / 2.0;
    double center_y = (min_pt.y + max_pt.y) / 2.0;
    double center_z = max_pt.z - box_z + 0.08;

    // 4.CollisionObject
    moveit_msgs::CollisionObject table_obj;
    table_obj.header.frame_id = "base_link";
    table_obj.id = "table";
    shape_msgs::SolidPrimitive primitive;
    primitive.type = primitive.BOX;
    primitive.dimensions = {box_x, box_y, box_z};
    geometry_msgs::Pose table_pose;
    table_pose.position.x = center_x;
    table_pose.position.y = center_y;
    table_pose.position.z = center_z;
    table_pose.orientation.w = 1.0;
    table_obj.primitives.push_back(primitive);
    table_obj.primitive_poses.push_back(table_pose);
    table_obj.operation = table_obj.ADD;

    // 5.Publisher
    planning_scene_interface_.applyCollisionObject(table_obj);

    table_obstacle_initialized_ = true;
    if (table_cloud_sub_once_) table_cloud_sub_once_.shutdown();
    
    ROS_INFO("Apply table obstacle: center(%.3f,%.3f,%.3f) size(%.3f,%.3f,%.3f)",
             center_x, center_y, center_z, box_x, box_y, box_z);
}

// =======================
//   抓取主函数（含质心 / PCA / 姿态输出 + RViz 坐标轴）
// =======================
bool Grasper::grasp(const sensor_msgs::PointCloud2ConstPtr& msg, int target_label)
{
    // Step 1: Convert PointCloud2 to PCL PointCloud<PointXYZL>
    pcl::PointCloud<PointT1>::Ptr cloud(new pcl::PointCloud<PointT1>);
    pcl::fromROSMsg(*msg, *cloud);

    // Step 2: Extract all points with the target label
    std::vector<PointT1> target_points;
    target_points.reserve(cloud->points.size());
    for (const auto& pt : cloud->points)
    {
        if (pt.label == target_label)
            target_points.push_back(pt);
    }

    if (target_points.empty())
    {
        ROS_WARN("No points found with label %d", target_label);
        return false;
    }

    // Step 3: Compute centroid of the target cluster
    Eigen::Vector3d centroid(0, 0, 0);
    for (const auto& pt : target_points)
        centroid += Eigen::Vector3d(pt.x, pt.y, pt.z);
    centroid /= static_cast<double>(target_points.size());

    ROS_INFO("Centroid of target label %d: [%.3f, %.3f, %.3f]",
             target_label, centroid.x(), centroid.y(), centroid.z());

    // ========= PCA 主轴分析 =========
    const size_t N = target_points.size();
    Eigen::MatrixXd M(N, 3);

    for (size_t i = 0; i < N; ++i)
    {
        M(i, 0) = target_points[i].x;
        M(i, 1) = target_points[i].y;
        M(i, 2) = target_points[i].z;
    }

    // 去中心化
    Eigen::Vector3d mean = M.colwise().mean();
    for (size_t i = 0; i < N; ++i)
        M.row(i) -= mean.transpose();

    // 协方差矩阵 & 特征分解
    Eigen::Matrix3d cov = (M.transpose() * M) / static_cast<double>(N);
    Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> es(cov);
    Eigen::Vector3d eigvals = es.eigenvalues();   // 升序
    Eigen::Matrix3d eigvecs = es.eigenvectors();  // 列为特征向量

    Eigen::Vector3d axis_thin = eigvecs.col(0);
    Eigen::Vector3d axis_mid  = eigvecs.col(1);
    Eigen::Vector3d axis_long = eigvecs.col(2);

    ROS_INFO("\n=== PCA RESULT (lambda, axis) ===");
    ROS_INFO("  lambda_thin = %.6f, axis_thin = [%.3f, %.3f, %.3f]",
             eigvals(0), axis_thin.x(), axis_thin.y(), axis_thin.z());
    ROS_INFO("  lambda_mid  = %.6f, axis_mid  = [%.3f, %.3f, %.3f]",
             eigvals(1), axis_mid.x(),  axis_mid.y(),  axis_mid.z());
    ROS_INFO("  lambda_long = %.6f, axis_long = [%.3f, %.3f, %.3f]",
             eigvals(2), axis_long.x(), axis_long.y(), axis_long.z());

    // 与世界坐标 z 轴的夹角（判断躺着/竖着）
    Eigen::Vector3d world_z(0, 0, 1);
    double cos_angle = std::fabs(axis_long.dot(world_z));  // 0 = 完全水平, 1 = 完全竖直
    ROS_INFO("cos(angle(long_axis, z_world)) = %.3f", cos_angle);

    bool is_horizontal = (cos_angle < 0.4);
    if (is_horizontal)
    {
        ROS_WARN("[JUDGE] Object judged as HORIZONTAL (lying object).");
        ROS_INFO("[STRATEGY] 目前仍使用参数 grasp_rpy_，只做信息输出，不改变抓取方向。");
    }
    else
    {
        ROS_INFO("[JUDGE] Object judged as VERTICAL (standing object).");
        ROS_INFO("[STRATEGY] 目前仍使用参数 grasp_rpy_，只做信息输出，不改变抓取方向。");
    }

    // 在 RViz 中发布 PCA 轴（物体坐标系）
    // 这里我们用 axis_long 做 X，axis_mid 做 Y，axis_thin 做 Z
    publishAxesMarkers(centroid,
                       axis_long,   // X
                       axis_mid,    // Y
                       axis_thin,   // Z
                       msg->header.frame_id);

    // ========= PCA 部分结束 =========

    // Step 4: Construct grasp pose (仍然使用参数中的 RPY)
    tf::Quaternion q;
    q.setRPY(grasp_rpy_[0], grasp_rpy_[1], grasp_rpy_[2]);
    geometry_msgs::Quaternion quat;
    tf::quaternionTFToMsg(q, quat);

    // --- Grasp Pose ---
    geometry_msgs::PoseStamped grasp_pose;
    grasp_pose.header.frame_id = msg->header.frame_id;
    grasp_pose.header.stamp = ros::Time::now();
    grasp_pose.pose.position.x = centroid.x() + x_offset_; 
    grasp_pose.pose.position.y = centroid.y() + y_offset_;
    grasp_pose.pose.position.z = centroid.z() + z_offset_;
    grasp_pose.pose.orientation = quat;
    
    // 从四元数计算末端坐标系的三个轴，并打印出来
    tf::Matrix3x3 rot_mat(q);
    tf::Vector3 x_axis = rot_mat * tf::Vector3(1.0, 0.0, 0.0);  // approach
    tf::Vector3 y_axis = rot_mat * tf::Vector3(0.0, 1.0, 0.0);  // closing
    tf::Vector3 z_axis = rot_mat * tf::Vector3(0.0, 0.0, 1.0);  // normal

    ROS_INFO("\nFinal EE axes in world (from grasp_rpy_):");
    ROS_INFO("  X (approach) = [%.3f, %.3f, %.3f]", x_axis.x(), x_axis.y(), x_axis.z());
    ROS_INFO("  Y (closing)  = [%.3f, %.3f, %.3f]", y_axis.x(), y_axis.y(), y_axis.z());
    ROS_INFO("  Z (normal)   = [%.3f, %.3f, %.3f]", z_axis.x(), z_axis.y(), z_axis.z());

    // --- Pregrasp Pose ---
    geometry_msgs::PoseStamped pregrasp_pose = grasp_pose;
    pregrasp_pose.pose.position.x += pregrasp_offset_x;
    pregrasp_pose.pose.position.y += pregrasp_offset_y;
    pregrasp_pose.pose.position.z += pregrasp_offset_z; 

    // Step 5: Move the arm
    // Move to pregrasp
    if (!moveArmToTarget(pregrasp_pose)) {
        ROS_ERROR("Failed to move to pregrasp pose.");
        ros::shutdown();
        return false;
    }
    ROS_INFO("Pregrasp done");
    ros::Duration(1.0).sleep();

    // Move to grasp（沿给定方向直线）
    if (!moveEndEffectorStraightDirection(1, 0, -1, 0.16))
    {
        ROS_ERROR("Failed to move to grasp pose.");
        ros::shutdown();
        return false;
    }
    ROS_INFO("Grasp pose done");
    ros::Duration(1.0).sleep();

    closeGripper();
    ros::Duration(1.0).sleep();

    if (!moveEndEffectorStraightDirection(0, 0, 1, 0.01))
    {
        ROS_ERROR("Failed to lift.");
        ros::shutdown();
        return false;
    }
    ROS_INFO("Grasp pose done");
    ros::Duration(1.0).sleep();
    
    ros::shutdown();
    return true;
}

// =======================
//   关节空间移动到目标位姿
// =======================
bool Grasper::moveArmToTarget(const geometry_msgs::PoseStamped& target)
{
    ROS_INFO("MoveArmToTarget: setPoseTarget");
    move_group_.setPoseTarget(target);
    move_group_.setMaxVelocityScalingFactor(0.2);  // default 0.3
    move_group_.setMaxAccelerationScalingFactor(0.1);

    ROS_INFO("MoveArmToTarget: start move");
    auto result = move_group_.move();
    ROS_INFO("MoveArmToTarget: move finished");

    if (result != moveit::planning_interface::MoveItErrorCode::SUCCESS)
    {
        ROS_ERROR("Motion execution failed.");
        return false;
    }

    return true;
}

// =======================
//   末端按直线方向移动
// =======================
bool Grasper::moveEndEffectorStraightDirection(double dx, double dy, double dz, double distance)
{
    // normalized direction vector
    Eigen::Vector3d dir(dx, dy, dz);
    if (dir.norm() < 1e-6) {
        ROS_ERROR("Direction vector is zero!");
        return false;
    }
    dir.normalize();

    // get the current end-effector pose
    geometry_msgs::PoseStamped current_pose =
        move_group_.getCurrentPose(move_group_.getEndEffectorLink());
    geometry_msgs::Pose start = current_pose.pose;
    geometry_msgs::Pose target = start;

    // calculate the target point
    target.position.x += dir.x() * distance;
    target.position.y += dir.y() * distance;
    target.position.z += dir.z() * distance;

    std::vector<geometry_msgs::Pose> waypoints;
    waypoints.push_back(start);
    waypoints.push_back(target);

    moveit_msgs::RobotTrajectory trajectory;
    double fraction =
        move_group_.computeCartesianPath(waypoints, 0.005, 0.0, trajectory);

    ROS_INFO("Path fraction: %.2f", fraction);
    if (fraction < 0.99) {
        ROS_ERROR("Cartesian path planning failed");
        return false;
    }

    moveit::planning_interface::MoveGroupInterface::Plan plan;
    plan.trajectory_ = trajectory;
    if (move_group_.execute(plan) !=
        moveit::planning_interface::MoveItErrorCode::SUCCESS) {
        ROS_ERROR("Cartesian execution failed");
        return false;
    }
    ROS_INFO("Move along direction finished");
    return true;
}

// =======================
//        闭合夹爪
// =======================
void Grasper::closeGripper()
{
    trajectory_msgs::JointTrajectory traj;
    traj.joint_names =
        {"gripper_left_finger_joint", "gripper_right_finger_joint"};

    trajectory_msgs::JointTrajectoryPoint pt;
    pt.positions = {0.0, 0.0}; // close
    pt.time_from_start = ros::Duration(3.0);
    traj.points.push_back(pt);
    traj.header.stamp = ros::Time::now() + ros::Duration(0.2);

    for (int i = 0; i < 3; ++i)
    {
        gripper_pub_.publish(traj);
        ros::Duration(0.1).sleep();
    }
}

// =======================
//   在 RViz 中画物体坐标轴 / PCA 轴
// =======================
void Grasper::publishAxesMarkers(const Eigen::Vector3d& centroid,
                                 const Eigen::Vector3d& axis_x,
                                 const Eigen::Vector3d& axis_y,
                                 const Eigen::Vector3d& axis_z,
                                 const std::string& frame_id)
{
    if (axis_marker_pub_.getNumSubscribers() == 0)
        return;  // 没有 RViz 订阅时就不发

    visualization_msgs::MarkerArray array_msg;
    array_msg.markers.reserve(3);

    // 三个轴的长度
    double length = 0.15;  // 15 cm

    auto make_axis_marker = [&](int id,
                                const Eigen::Vector3d& dir,
                                float r, float g, float b,
                                const std::string& ns) -> visualization_msgs::Marker
    {
        visualization_msgs::Marker m;
        m.header.frame_id = frame_id;
        m.header.stamp    = ros::Time::now();
        m.ns   = ns;
        m.id   = id;
        m.type = visualization_msgs::Marker::LINE_LIST;
        m.action = visualization_msgs::Marker::ADD;

        // 线宽
        m.scale.x = 0.01;  // 1 cm

        m.color.r = r;
        m.color.g = g;
        m.color.b = b;
        m.color.a = 1.0;

        geometry_msgs::Point p0, p1;
        p0.x = centroid.x();
        p0.y = centroid.y();
        p0.z = centroid.z();

        Eigen::Vector3d end = centroid + dir.normalized() * length;
        p1.x = end.x();
        p1.y = end.y();
        p1.z = end.z();

        m.points.push_back(p0);
        m.points.push_back(p1);

        return m;
    };

    // X / Y / Z 三个轴：用不同颜色
    array_msg.markers.push_back(make_axis_marker(
        0, axis_x, 1.0f, 0.0f, 0.0f, "axis_x"));  // 红色 X

    array_msg.markers.push_back(make_axis_marker(
        1, axis_y, 0.0f, 1.0f, 0.0f, "axis_y"));  // 绿色 Y

    array_msg.markers.push_back(make_axis_marker(
        2, axis_z, 0.0f, 0.0f, 1.0f, "axis_z"));  // 蓝色 Z

    axis_marker_pub_.publish(array_msg);
}

