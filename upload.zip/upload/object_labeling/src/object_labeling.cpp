#include <object_labeling/object_labeling.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/search/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/common/centroid.h>

#include <limits>
#include <Eigen/Dense>  // 为了 Eigen::SelfAdjointEigenSolver

// =======================
//    构造 & 析构
// =======================
ObjectLabeling::ObjectLabeling(
    const std::string& objects_cloud_topic, 
    const std::string& camera_info_topic,
    const std::string& camera_frame) :
  is_cloud_updated_(false),
  has_camera_info_(false),
  objects_cloud_topic_(objects_cloud_topic),
  camera_info_topic_(camera_info_topic),
  camera_frame_(camera_frame),
  K_(Eigen::Matrix3d::Zero())
{
}

ObjectLabeling::~ObjectLabeling()
{
}

// =======================
//      初始化
// =======================
bool ObjectLabeling::initalize(ros::NodeHandle& nh)
{
  // Subscribe to objects pointcloud published by the plane_segmentation_node
  object_point_cloud_sub_ =
      nh.subscribe(objects_cloud_topic_, 10,
                   &ObjectLabeling::cloudCallback, this);

  // Subscribe to bounding boxes from yolo (object_labeling_node)
  object_detections_sub_ =
      nh.subscribe("/darknet_ros/bounding_boxes", 10,
                   &ObjectLabeling::detectionCallback, this);

  // Subscribe to camera info from robot to obtain the camera matrix K
  camera_info_sub_ =
      nh.subscribe(camera_info_topic_, 10,
                   &ObjectLabeling::cameraInfoCallback, this);

  // Publish the labeled objects as PointCloud type
  labeled_object_cloud_pub_ =
      nh.advertise<sensor_msgs::PointCloud2>("/labeled_object_point_cloud", 1);

  // Publish the LABELED object names as visualization marker
  text_marker_pub_ =
      nh.advertise<visualization_msgs::MarkerArray>("/text_markers", 1);

  // 发布聚类质心（调试用）
  centroid_pub_ =
      nh.advertise<geometry_msgs::PointStamped>("cluster_centroid", 1);
  
  // ✅ 发布每个物体的局部坐标轴（X/Y/Z）
  axes_marker_pub_ =
      nh.advertise<visualization_msgs::MarkerArray>("/object_axes_markers", 1);
  
  // init internal pointclouds for processing
  object_point_cloud_.reset(new PointCloud);    // holds unlabeled object point cloud
  labeled_point_cloud_.reset(new PointCloudl);  // holds labeled object point cloud

  // class-name -> label-id 映射
  // Note: 0 作为 'unknown'
  dict_["bottle"] = 1;
  dict_["cup"]    = 2;
  dict_["person"] = 5;

  return true;
}

// =======================
//      主循环 update
// =======================
void ObjectLabeling::update(const ros::Time& time)
{
  // camera info and point cloud available
  if (is_cloud_updated_ && has_camera_info_)
  {
    is_cloud_updated_ = false;

    // label the objects in pointcloud based on 2d bounding boxes 
    if (!labelObjects(object_point_cloud_, labeled_point_cloud_))
    {
      ROS_WARN("Object labeling failed.");
      return;
    }
    
    // Publish labeled_point_cloud_ to ros
    sensor_msgs::PointCloud2 labeled_point_cloud_msg;
    pcl::toROSMsg(*labeled_point_cloud_, labeled_point_cloud_msg);
    labeled_point_cloud_msg.header.frame_id = object_point_cloud_->header.frame_id;
    labeled_point_cloud_msg.header.stamp = time;
    labeled_object_cloud_pub_.publish(labeled_point_cloud_msg);

    // Publish text_markers_ to ros
    for (auto& marker : text_markers_.markers) {
      marker.header.frame_id = object_point_cloud_->header.frame_id;
      marker.header.stamp = time;
    }
    text_marker_pub_.publish(text_markers_);
  }
}

// =======================
//   打标签主逻辑 + PCA 可视化
// =======================
bool ObjectLabeling::labelObjects(CloudPtr& input, CloudPtrl& output)
{
  // 1. Euclidean clustering
  if (!input || input->empty()) {
    ROS_WARN("Input cloud is null or empty!");
    return false;
  }

  pcl::search::KdTree<PointT>::Ptr tree(new pcl::search::KdTree<PointT>);
  tree->setInputCloud(input);
  
  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<PointT> ec;
  ec.setClusterTolerance(0.02);
  ec.setMinClusterSize(80);
  ec.setMaxClusterSize(25000);
  ec.setSearchMethod(tree);
  ec.setInputCloud(input);
  ec.extract(cluster_indices);

  if (cluster_indices.empty()) {
    ROS_WARN("Euclidean clustering found no clusters!");
    return false;
  }

  // =======================
  // 2. 对每个 cluster 计算质心 + PCA
  // =======================
  std::vector<Eigen::Vector3d> centroids;
  centroids.reserve(cluster_indices.size());

  // 用于发布坐标轴的 MarkerArray
  visualization_msgs::MarkerArray axes_markers;
  axes_markers.markers.reserve(cluster_indices.size() * 3);

  // 每个 cluster 的颜色 / id 基数
  int axis_marker_id = 0;

  for (size_t ci = 0; ci < cluster_indices.size(); ++ci)
  {
    const auto& indices = cluster_indices[ci];

    pcl::PointCloud<PointT>::Ptr cloud_cluster(new pcl::PointCloud<PointT>);
    cloud_cluster->reserve(indices.indices.size());
    for (const auto& idx : indices.indices)
    {
      cloud_cluster->push_back(input->points[idx]);
    }

    // ---- 计算质心 ----
    Eigen::Vector4d centroid4;
    pcl::compute3DCentroid(*cloud_cluster, centroid4);
    Eigen::Vector3d centroid = centroid4.head<3>();
    centroids.push_back(centroid);

    // 发布质心（调试用）
    geometry_msgs::PointStamped centroid_msg;
    centroid_msg.header.frame_id = input->header.frame_id;  // 跟点云同一个坐标系
    centroid_msg.header.stamp = ros::Time::now();
    centroid_msg.point.x = centroid[0];
    centroid_msg.point.y = centroid[1];
    centroid_msg.point.z = centroid[2];
    centroid_pub_.publish(centroid_msg);

    // ---- 对该 cluster 做 PCA，得到物体局部坐标轴 ----
    const size_t N = cloud_cluster->points.size();
    if (N < 5) {
      // 点太少就不做 PCA 了
      continue;
    }

    Eigen::MatrixXd M(N, 3);
    for (size_t i = 0; i < N; ++i)
    {
      const auto& p = cloud_cluster->points[i];
      M(i, 0) = p.x;
      M(i, 1) = p.y;
      M(i, 2) = p.z;
    }

    // 去中心化
    Eigen::Vector3d mean = M.colwise().mean();
    for (size_t i = 0; i < N; ++i)
      M.row(i) -= mean.transpose();

    Eigen::Matrix3d cov = (M.transpose() * M) / static_cast<double>(N);
    Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> es(cov);
    Eigen::Vector3d eigvals = es.eigenvalues();   // 升序
    Eigen::Matrix3d eigvecs = es.eigenvectors();  // 列为特征向量

    Eigen::Vector3d axis_thin = eigvecs.col(0);
    Eigen::Vector3d axis_mid  = eigvecs.col(1);
    Eigen::Vector3d axis_long = eigvecs.col(2);

    ROS_INFO("Cluster %zu PCA: lambda=[%.4f, %.4f, %.4f]", ci,
             eigvals(0), eigvals(1), eigvals(2));

    // =======================
    //   生成三个坐标轴的 Marker
    // =======================
    auto make_axis_marker = [&](int id,
                                const Eigen::Vector3d& dir,
                                float r, float g, float b,
                                const std::string& ns) -> visualization_msgs::Marker
    {
      visualization_msgs::Marker m;
      m.header.frame_id = input->header.frame_id;   // 与点云同一坐标系
      m.header.stamp    = ros::Time::now();
      m.ns   = ns;
      m.id   = id;
      m.type = visualization_msgs::Marker::LINE_LIST;
      m.action = visualization_msgs::Marker::ADD;

      // 线宽
      m.scale.x = 0.01;  // 1 cm

      m.color.r = r;
      m.color.g = g;
      m.color.b = b;
      m.color.a = 1.0;

      double length = 0.15;  // 15 cm

      geometry_msgs::Point p0, p1;
      p0.x = centroid.x();
      p0.y = centroid.y();
      p0.z = centroid.z();

      Eigen::Vector3d end = centroid + dir.normalized() * length;
      p1.x = end.x();
      p1.y = end.y();
      p1.z = end.z();

      m.points.push_back(p0);
      m.points.push_back(p1);

      return m;
    };

    // X/Y/Z 三轴：使用不同颜色
    axes_markers.markers.push_back(
        make_axis_marker(axis_marker_id++, axis_long, 1.0f, 0.0f, 0.0f, "cluster_axis_x")); // 红
    axes_markers.markers.push_back(
        make_axis_marker(axis_marker_id++, axis_mid,  0.0f, 1.0f, 0.0f, "cluster_axis_y")); // 绿
    axes_markers.markers.push_back(
        make_axis_marker(axis_marker_id++, axis_thin, 0.0f, 0.0f, 1.0f, "cluster_axis_z")); // 蓝
  }

  // ✅ 强制发布所有 cluster 的坐标轴（不再检查订阅数）
  if (!axes_markers.markers.empty())
  {
    axes_marker_pub_.publish(axes_markers);
  }

  // =======================
  // 3. TF: base_footprint -> camera_frame
  // =======================
  tf::StampedTransform transform;
  try
  {
    tfListener_.lookupTransform("base_footprint", camera_frame_,
                                ros::Time(0), transform);
  }
  catch (tf::TransformException& ex)
  {
    ROS_WARN("TF lookup failed: %s", ex.what());
    return false;
  }

  Eigen::Affine3d T_base_camera;
  tf::transformTFToEigen(transform, T_base_camera);  // camera -> base
  Eigen::Affine3d T_camera_base = T_base_camera.inverse(); // base -> camera

  // 4. Transform the centroids to the camera coordinate frame
  std::vector<Eigen::Vector3d> centroids_camera;
  centroids_camera.reserve(centroids.size());
  for (const auto& c : centroids)
    centroids_camera.push_back(T_camera_base * c);

  // 5. Camera projection: 3D -> 2D
  std::vector<Eigen::Vector2d> pixel_centroids;
  pixel_centroids.reserve(centroids_camera.size());

  for (const auto& c_cam : centroids_camera)
  {
    Eigen::Vector3d uvw = K_ * c_cam;   // [u*Z, v*Z, Z]
    if (std::fabs(uvw[2]) < 1e-6)
      continue;
    uvw /= uvw[2];
    pixel_centroids.emplace_back(uvw[0], uvw[1]);
  }

  if (pixel_centroids.size() != centroids.size())
  {
    ROS_WARN("Some centroids could not be projected correctly.");
  }

  // 6. Assign each detection box to the nearest centroid
  std::vector<int> assigned_labels(cluster_indices.size(), 0);                  // labels
  std::vector<std::string> assigned_classes(cluster_indices.size(), "unknown"); // class names

  for (size_t i = 0; i < detections_.size(); ++i)
  {
    const darknet_ros_msgs::BoundingBox& bounding_box = detections_[i];

    // bounding box center in pixel
    Eigen::Vector2d bb_center(
      (bounding_box.xmax + bounding_box.xmin) / 2.0,
      (bounding_box.ymax + bounding_box.ymin) / 2.0);

    int match = -1;
    double closest_distance = std::numeric_limits<double>::max();

    for (size_t j = 0; j < pixel_centroids.size(); ++j)
    {
      double distance = (pixel_centroids[j] - bb_center).norm();
      if (distance < closest_distance)
      {
        closest_distance = distance;
        match = static_cast<int>(j);
      }
    }

    if (match >= 0)
    {
      auto it = dict_.find(bounding_box.Class);
      if (it != dict_.end())
      {
        assigned_labels[match]  = it->second;
        assigned_classes[match] = bounding_box.Class;
      }
    }
  }

  // 7. Reconstruct and build the labeled point cloud
  output->points.clear();
  output->header = input->header;

  PointTl pt;
  size_t i = 0;
  auto cit = cluster_indices.begin();
  for (; cit != cluster_indices.end(); ++cit, ++i)
  {
    const auto& indices = cit->indices;
    for (int idx : indices)
    {
      PointT& cpt = input->points[idx];
      pt.x = cpt.x;
      pt.y = cpt.y;
      pt.z = cpt.z;
      pt.label = assigned_labels[i];    // 0 = unknown
      output->points.push_back(pt);
    }
  }

  // 8. Generate text annotation markers
  text_markers_.markers.clear();
  text_markers_.markers.reserve(assigned_classes.size());

  for (size_t i = 0; i < assigned_classes.size(); ++i)
  {
    visualization_msgs::Marker marker;
    marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
    marker.text = assigned_classes[i];
    marker.pose.position.x = centroids[i].x();
    marker.pose.position.y = centroids[i].y();
    marker.pose.position.z = centroids[i].z() + 0.1;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.scale.z = 0.1;
    marker.id = static_cast<int>(i);
    marker.header.frame_id = input->header.frame_id;
    marker.header.stamp = ros::Time::now();
    text_markers_.markers.push_back(marker);
  }

  return true;
}

// =======================
//  回调：点云
// =======================
void ObjectLabeling::cloudCallback(const sensor_msgs::PointCloud2ConstPtr &msg)
{
  is_cloud_updated_ = true;
  pcl::fromROSMsg(*msg, *object_point_cloud_);
}

// =======================
//  回调：YOLO 检测框
// =======================
void ObjectLabeling::detectionCallback(
    const darknet_ros_msgs::BoundingBoxesConstPtr &msg)
{
  detections_ = msg->bounding_boxes;
}

// =======================
//  回调：CameraInfo
// =======================
void ObjectLabeling::cameraInfoCallback(
    const sensor_msgs::CameraInfoConstPtr &msg)
{
  has_camera_info_ = true;

  // Camera matrix K is 3x3, stored row-major in msg->K[0..8]
  K_(0,0) = msg->K[0];
  K_(0,1) = msg->K[1];
  K_(0,2) = msg->K[2];
  K_(1,0) = msg->K[3];
  K_(1,1) = msg->K[4];
  K_(1,2) = msg->K[5];
  K_(2,0) = msg->K[6];
  K_(2,1) = msg->K[7];
  K_(2,2) = msg->K[8];
}

